'use strict';
/* Çekirdek: sabitler, yardımcılar, veri katmanı, istatistikler */
const M = window.M = {};
(() => {
const KEY = 'mesai.v5', V4 = 'mesai.v4', V3 = 'mesai.v3', V2 = 'mesaiTakipPremium_v2';

M.MONTHS = ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
M.MONTHS_S = ['Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'];
M.DAYS = ['Pazar','Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi'];
M.DAYS_S = ['Paz','Pzt','Sal','Çar','Per','Cum','Cmt'];
M.TYPES = { normal: 'Hafta içi', weekend: 'Hafta sonu', holiday: 'Resmi tatil' };
M.TCOL = { normal: 'var(--t1)', weekend: 'var(--t2)', holiday: 'var(--t3)' };

M.pad = n => String(n).padStart(2, '0');
M.iso = d => `${d.getFullYear()}-${M.pad(d.getMonth() + 1)}-${M.pad(d.getDate())}`;
M.parse = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
M.esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
M.uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
M.dur = m => { m = Math.round(m); const h = Math.floor(m / 60), mm = m % 60; return h ? (mm ? `${h} sa ${mm} dk` : `${h} sa`) : `${mm} dk`; };
M.hm = m => `${Math.floor(m / 60)}:${M.pad(Math.round(m) % 60)}`;
M.pretty = s => { const [y, m, d] = s.split('-'); return `${d}.${m}.${y}`; };
M.longDate = s => { const d = M.parse(s); return `${d.getDate()} ${M.MONTHS[d.getMonth()]} ${d.getFullYear()}, ${M.DAYS[d.getDay()]}`; };
M.autoType = s => { if (M.isHolidayPay && M.isHolidayPay(s)) return 'holiday'; const w = M.parse(s).getDay(); return (w === 0 || w === 6) ? 'weekend' : 'normal'; };
M.dayNum = s => { const [y, m, d] = s.split('-').map(Number); return Math.round(Date.UTC(y, m - 1, d) / 864e5); };
M.daysIn = (y, m) => new Date(y, m, 0).getDate();
M.today = () => M.iso(new Date());
M.addMonths = (key, n) => { const [y, m] = key.split('-').map(Number); const d = new Date(y, m - 1 + n, 1); return `${d.getFullYear()}-${M.pad(d.getMonth() + 1)}`; };
M.parseHM = v => {
  const s = String(v || '').trim().replace(',', ':');
  if (/^\d{1,3}:[0-5]\d$/.test(s)) { const [h, m] = s.split(':').map(Number); return h * 60 + m; }
  if (/^\d{1,4}$/.test(s)) return Number(s);
  return null;
};

M.DEF = {
  goal: 0, yearLimit: 270, wage: 0, mult: { normal: 1.5, weekend: 1.5, holiday: 2 }, cur: '₺',
  bank: false, weekStart: 1, theme: 'auto', pin: null, salt: null, hint: false, lastBackup: null,
  presets: [30, 60, 120, 180],
  salaries: [], divisor: 225, arife: true, customHolidays: [], net: { on: true, sgk: true, exempt: true },
  profile: { name: '', company: '', empNo: '', manager: '' }
};
const mergeSettings = s => {
  s = s || {};
  const okMonth = v => /^\d{4}-\d{2}$/.test(String(v));
  return { ...M.DEF, ...s, mult: { ...M.DEF.mult, ...(s.mult || {}) },
    presets: Array.isArray(s.presets) ? s.presets.filter(n => Number.isFinite(n) && n > 0).slice(0, 8) : M.DEF.presets.slice(),
    salaries: (Array.isArray(s.salaries) ? s.salaries : []).filter(e => e && okMonth(e.from) && Number(e.amount) > 0).map(e => ({ from: e.from, amount: Number(e.amount) })).sort((a, b) => a.from.localeCompare(b.from)),
    divisor: Number(s.divisor) > 0 ? Number(s.divisor) : 225,
    arife: s.arife !== false,
    net: { on: !(s.net && s.net.on === false), sgk: !(s.net && s.net.sgk === false), exempt: !(s.net && s.net.exempt === false) },
    customHolidays: (Array.isArray(s.customHolidays) ? s.customHolidays : []).filter(h => h && /^\d{4}-\d{2}-\d{2}$/.test(String(h.date))).map(h => ({ date: h.date, name: String(h.name || 'Özel tatil').slice(0, 40) })),
    profile: { ...M.DEF.profile, ...(s.profile || {}) } };
};

/* ---------- Veri ---------- */
M.norm = r => {
  if (!r || !/^\d{4}-\d{2}-\d{2}$/.test(String(r.date))) return null;
  const minutes = Math.round(Number(r.minutes));
  if (!Number.isFinite(minutes) || minutes <= 0 || minutes > 1440) return null;
  const kind = r.kind === 'leave' ? 'leave' : 'ot';
  return { id: String(r.id || M.uid()), date: r.date, minutes, kind,
    type: M.TYPES[r.type] ? r.type : M.autoType(r.date),
    note: String(r.note || '').slice(0, 200), tag: String(r.tag || '').trim().slice(0, 30),
    start: r.start || '', end: r.end || '' };
};
const load = () => {
  try {
    const d = JSON.parse(localStorage.getItem(KEY));
    if (d && Array.isArray(d.records)) return { records: d.records.map(M.norm).filter(Boolean), settings: mergeSettings(d.settings) };
  } catch (e) {}
  try {
    const d = JSON.parse(localStorage.getItem(V4));
    if (d && Array.isArray(d.records)) return { records: d.records.map(M.norm).filter(Boolean), settings: mergeSettings(d.settings) };
  } catch (e) {}
  try {
    const d = JSON.parse(localStorage.getItem(V3));
    if (d && Array.isArray(d.records)) return { records: d.records.map(M.norm).filter(Boolean), settings: mergeSettings(d.settings) };
  } catch (e) {}
  try {
    const o = JSON.parse(localStorage.getItem(V2) || '[]');
    if (Array.isArray(o) && o.length) return { records: o.map(M.norm).filter(Boolean), settings: mergeSettings() };
  } catch (e) {}
  return { records: [], settings: mergeSettings() };
};
M.db = load();
M.resetDb = () => { M.db = { records: [], settings: mergeSettings() }; };
M.mergeSettings = mergeSettings;
M.persist = () => { try { localStorage.setItem(KEY, JSON.stringify(M.db)); return true; } catch (e) { M.toast && M.toast('Kayıt saklanamadı!'); return false; } };

/* ---------- Seçiciler / hesaplar ---------- */
M.ot = () => M.db.records.filter(r => r.kind !== 'leave');
M.leaves = () => M.db.records.filter(r => r.kind === 'leave');
M.sum = rs => rs.reduce((a, r) => a + r.minutes, 0);
M.byDate = rs => rs.slice().sort((a, b) => b.date.localeCompare(a.date) || String(b.id).localeCompare(String(a.id)));
/* Brüt maaş (aylık) → saatlik ücret = maaş ÷ aylık çalışma saati (varsayılan 225). Maaş geçmişi (zam) ay bazında uygulanır. */
M.salaryAt = ym => {
  const l = M.db.settings.salaries; if (!l.length) return null;
  let a = l[0].amount; l.forEach(e => { if (e.from <= ym) a = e.amount; }); return a;
};
M.hourlyAt = date => { const s = M.db.settings; return s.salaries.length ? M.salaryAt(date.slice(0, 7)) / (s.divisor || 225) : s.wage; };
M.moneyOn = () => M.db.settings.salaries.length > 0 || M.db.settings.wage > 0;
M.earn = r => (r.kind === 'leave' || !M.moneyOn()) ? 0 : r.minutes / 60 * M.hourlyAt(r.date) * (M.db.settings.mult[r.type] || 1);
M.fmtMoney = n => Math.round(n).toLocaleString('tr-TR') + ' ' + M.db.settings.cur;
M.fmtMoney2 = n => n.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ' + M.db.settings.cur;
/* ---------- Net (ele geçen) tahmini ----------
   Yöntem: mesai neti = o ayın bordrosunda (maaş + mesai) netinin (yalnız maaş) netinden farkı. Kesintiler yıl içinde KÜMÜLATİF hesaplanır:
   SGK işçi %14 + işsizlik %1 (tavana kadar), gelir vergisi (kümülatif matrah, ücret tarifesi), damga vergisi (binde 7,59),
   asgari ücret gelir/damga vergisi istisnası. Mesai, yapıldığı ayın bordrosuna dahil sayılır. */
const NETP = {
  2025: { br: [[158000, .15], [330000, .20], [800000, .27], [4300000, .35], [Infinity, .40]], mw: 26005.5, cap: 195041.4 },
  2026: { br: [[190000, .15], [400000, .20], [1500000, .27], [5300000, .35], [Infinity, .40]], mw: 33030, cap: 297270 }
};
M.netPar = y => NETP[y] || (y > 2026 ? NETP[2026] : NETP[2025]);
M.netEstimated = y => !NETP[y];
const taxOn = (br, b) => { let t = 0, lo = 0; for (const [hi, r] of br) { if (b > lo) t += (Math.min(b, hi) - lo) * r; lo = hi; } return t; };
M.netOn = () => M.db.settings.net.on && M.db.settings.salaries.length > 0;
M.payYear = (y, ot) => {
  const s = M.db.settings, par = M.netPar(y), k = s.net.sgk ? 0.15 : 0, ex = s.net.exempt;
  let cum = 0, cumT = 0, cumMW = 0, cumMT = 0; const out = [];
  for (let i = 0; i < 12; i++) {
    const gross = (M.salaryAt(`${y}-${M.pad(i + 1)}`) || 0) + (ot[i] || 0);
    const sgk = Math.min(gross, par.cap) * k;
    cum += gross - sgk; const t = taxOn(par.br, cum); let tax = t - cumT; cumT = t;
    cumMW += par.mw * (1 - k); const mt = taxOn(par.br, cumMW), exT = mt - cumMT; cumMT = mt;
    if (ex) tax = Math.max(0, tax - exT);
    let dv = gross * 0.00759; if (ex) dv = Math.max(0, dv - par.mw * 0.00759);
    out.push({ gross, sgk, tax, dv, net: gross - sgk - tax - dv });
  }
  return out;
};
M.otNetYear = y => {
  /* Her ayın mesai neti = o ayın bordrosunda mesai ile mesaisiz fark (önceki ayların mesaisi kümülatif matraha dahil). */
  const ot = Array(12).fill(0);
  M.ot().forEach(r => { if (r.date.slice(0, 4) === String(y)) ot[Number(r.date.slice(5, 7)) - 1] += M.earn(r); });
  return ot.map((g, i) => {
    if (!g) return { gross: 0, net: 0, ded: 0, sgk: 0, tax: 0, dv: 0 };
    const w = M.payYear(y, ot.map((v, j) => j <= i ? v : 0))[i], b = M.payYear(y, ot.map((v, j) => j < i ? v : 0))[i], net = w.net - b.net;
    return { gross: g, net, ded: g - net, sgk: w.sgk - b.sgk, tax: w.tax - b.tax, dv: w.dv - b.dv };
  });
};
M.payOf = rs => {
  const t = { gross: 0, net: 0, ded: 0, sgk: 0, tax: 0, dv: 0 }; if (!M.netOn()) return null;
  const cache = {}, seen = new Set();
  rs.filter(r => r.kind !== 'leave').forEach(r => { const ym = r.date.slice(0, 7); if (seen.has(ym)) return; seen.add(ym);
    const y = ym.slice(0, 4), a = (cache[y] = cache[y] || M.otNetYear(y))[Number(ym.slice(5)) - 1]; Object.keys(t).forEach(k => { t[k] += a[k]; }); });
  return t;
};
M.bank = () => M.sum(M.ot()) - M.sum(M.leaves());
M.tagList = () => {
  const c = {}; M.db.records.forEach(r => { if (r.tag) c[r.tag] = (c[r.tag] || 0) + 1; });
  return Object.entries(c).sort((a, b) => b[1] - a[1]).map(x => x[0]);
};

M.monthStats = key => {
  const rs = M.ot().filter(r => r.date.slice(0, 7) === key);
  const perDay = {}, byType = { normal: 0, weekend: 0, holiday: 0 }, moneyBy = { normal: 0, weekend: 0, holiday: 0 }, byTag = {};
  let total = 0, money = 0;
  rs.forEach(r => {
    total += r.minutes; money += M.earn(r); moneyBy[r.type] += M.earn(r);
    perDay[r.date] = (perDay[r.date] || 0) + r.minutes;
    byType[r.type] += r.minutes;
    if (r.tag) byTag[r.tag] = (byTag[r.tag] || 0) + r.minutes;
  });
  const dates = Object.keys(perDay);
  let max = 0, maxDate = null;
  dates.forEach(d => { if (perDay[d] > max) { max = perDay[d]; maxDate = d; } });
  const [y, m] = key.split('-').map(Number), n = M.daysIn(y, m), ws = M.db.settings.weekStart;
  const first = (new Date(y, m - 1, 1).getDay() - ws + 7) % 7, nw = Math.ceil((n + first) / 7);
  const weeks = Array(nw).fill(0);
  dates.forEach(d => { weeks[Math.floor((Number(d.slice(8)) - 1 + first) / 7)] += perDay[d]; });
  const leave = M.sum(M.leaves().filter(r => r.date.slice(0, 7) === key));
  const pay = M.netOn() ? M.otNetYear(y)[m - 1] : null;
  return { key, y, m, n, first, rs, perDay, byType, moneyBy, byTag, total, money, pay, net: pay ? pay.net : 0, days: dates.length,
    avg: dates.length ? Math.round(total / dates.length) : 0, max, maxDate, weeks, leave };
};

M.yearStats = y => {
  const months = Array.from({ length: 12 }, () => ({ total: 0, days: new Set(), money: 0 }));
  const weekday = Array(7).fill(0), byType = { normal: 0, weekend: 0, holiday: 0 }, byTag = {}, heat = {};
  let total = 0, money = 0;
  M.ot().filter(r => r.date.slice(0, 4) === String(y)).forEach(r => {
    const mo = months[Number(r.date.slice(5, 7)) - 1];
    mo.total += r.minutes; mo.days.add(r.date); mo.money += M.earn(r);
    weekday[M.parse(r.date).getDay()] += r.minutes; byType[r.type] += r.minutes;
    if (r.tag) byTag[r.tag] = (byTag[r.tag] || 0) + r.minutes;
    heat[r.date] = (heat[r.date] || 0) + r.minutes;
    total += r.minutes; money += M.earn(r);
  });
  const pays = M.netOn() ? M.otNetYear(y) : null;
  months.forEach((m, i) => { m.days = m.days.size; m.net = pays ? pays[i].net : 0; });
  const net = months.reduce((a, m) => a + m.net, 0), ded = money - net;
  const active = months.filter(m => m.total > 0).length;
  let best = -1; months.forEach((m, i) => { if (m.total > 0 && (best < 0 || m.total > months[best].total)) best = i; });
  return { y, months, weekday, byType, byTag, heat, total, money, net, ded, pays, active, best,
    avg: active ? Math.round(total / active) : 0, days: months.reduce((a, m) => a + m.days, 0) };
};

M.streak = () => {
  const ds = [...new Set(M.ot().map(r => r.date))].sort();
  let best = 0, cur = 0, prev = null;
  ds.forEach(d => { const n = M.dayNum(d); cur = (prev !== null && n - prev === 1) ? cur + 1 : 1; if (cur > best) best = cur; prev = n; });
  return best;
};

M.years = () => {
  const ys = new Set(M.db.records.map(r => Number(r.date.slice(0, 4)))); ys.add(new Date().getFullYear());
  return [...ys].sort((a, b) => a - b);
};

/* ---------- Sayaç (Başlat / Bitir) ---------- */
M.timer = {
  get() { try { const t = JSON.parse(localStorage.getItem('mesai.timer')); return t && t.start ? t : null; } catch (e) { return null; } },
  start() { try { localStorage.setItem('mesai.timer', JSON.stringify({ start: Date.now() })); } catch (e) {} },
  clear() { try { localStorage.removeItem('mesai.timer'); } catch (e) {} }
};
M.clock = ms => { const t = Math.max(0, Math.floor(ms / 1000)); return `${M.pad(Math.floor(t / 3600))}:${M.pad(Math.floor(t / 60) % 60)}:${M.pad(t % 60)}`; };

/* ---------- Hafta özeti, seri, rozetler ---------- */
M.weekStartOf = iso => { const d = M.parse(iso), diff = (d.getDay() - M.db.settings.weekStart + 7) % 7; d.setDate(d.getDate() - diff); return M.iso(d); };
M.weekStats = () => {
  const per = {}; M.ot().forEach(r => { per[r.date] = (per[r.date] || 0) + r.minutes; });
  const start = M.weekStartOf(M.today()), days = [];
  const add = (iso, n) => { const d = M.parse(iso); d.setDate(d.getDate() + n); return M.iso(d); };
  for (let i = 0; i < 7; i++) { const d = add(start, i); days.push({ date: d, min: per[d] || 0 }); }
  let prev = 0; for (let i = 1; i <= 7; i++) prev += per[add(start, -i)] || 0;
  return { days, total: days.reduce((a, d) => a + d.min, 0), prev, start };
};
M.streakCurrent = () => {
  const set = new Set(M.ot().map(r => r.date)); let d = M.parse(M.today());
  if (!set.has(M.iso(d))) d.setDate(d.getDate() - 1);
  let n = 0; while (set.has(M.iso(d))) { n++; d.setDate(d.getDate() - 1); } return n;
};
M.badges = () => {
  const ot = M.ot(), tot = M.sum(ot), best = M.streak(), goal = M.db.settings.goal * 60, perM = {}, dates = new Map();
  ot.forEach(r => { const k = r.date.slice(0, 7); perM[k] = (perM[k] || 0) + r.minutes; if (!dates.has(r.date)) dates.set(r.date, r.type); });
  const maxM = Math.max(0, ...Object.values(perM)), wk = [...dates.values()].filter(t => t === 'weekend' || t === 'holiday').length, hol = [...dates.values()].filter(t => t === 'holiday').length;
  const b = (id, ico, name, desc, got) => ({ id, ico, name, desc, got });
  return [
    b('first', '🌱', 'İlk adım', 'İlk mesai kaydı', ot.length >= 1),
    b('h10', '⏱️', '10 saat', 'Toplam 10 saat mesai', tot >= 600),
    b('h50', '🔥', '50 saat', 'Toplam 50 saat mesai', tot >= 3000),
    b('h100', '💪', '100 saat', 'Toplam 100 saat mesai', tot >= 6000),
    b('h250', '🏅', '250 saat', 'Toplam 250 saat mesai', tot >= 15000),
    b('h500', '🏆', '500 saat', 'Toplam 500 saat mesai', tot >= 30000),
    b('s3', '📅', '3 gün seri', 'Üst üste 3 gün mesai', best >= 3),
    b('s7', '🚀', '7 gün seri', 'Üst üste 7 gün mesai', best >= 7),
    b('m50', '📈', 'Yoğun ay', 'Bir ayda 50 saat', maxM >= 3000),
    b('wk5', '🌙', 'Hafta sonu', '5 hafta sonu / tatil günü', wk >= 5),
    b('hol1', '🎌', 'Bayram mesaisi', 'Resmi tatilde mesai', hol >= 1),
    b('goal', '🎯', 'Hedef tuttu', 'Aylık hedefe ulaşma', goal > 0 && maxM >= goal)
  ];
};

M.isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
M.standalone = () => window.navigator.standalone === true || (window.matchMedia && matchMedia('(display-mode: standalone)').matches);

/* durum */
M.state = { view: 'home', month: M.today().slice(0, 7), year: new Date().getFullYear(), calMode: 'cal', selDay: null, q: '', filter: 'all' };
})();
