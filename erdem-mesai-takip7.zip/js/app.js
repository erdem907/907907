'use strict';
/* Uygulama: ekle/düzenle sayfası, PIN kilidi, dışa aktarma, olaylar */
(() => {
const { MONTHS, DAYS, TYPES, esc, dur, hm, pad, parse, pretty } = M;
const st = M.state, $ = (s, r = document) => r.querySelector(s);
const set = () => M.db.settings;
const num = v => Math.max(0, parseFloat(String(v).replace(',', '.')) || 0);

/* ---------- Bildirim (toast) ---------- */
let toastT;
M.toast = (msg, act) => {
  const t = $('#toast');
  t.innerHTML = esc(msg) + (act ? `<button id="toastAct">${esc(act.label)}</button>` : '');
  t.classList.add('show'); t.classList.toggle('act', !!act);
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), act ? 5500 : 2200);
  if (act) $('#toastAct').onclick = () => { t.classList.remove('show'); act.fn(); };
};
const toast = M.toast;

async function outFile(name, type, text) {
  const blob = new Blob([text], { type });
  try {
    const file = new File([blob], name, { type });
    if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], title: name }); return true; }
  } catch (e) { if (e && e.name === 'AbortError') return false; }
  const url = URL.createObjectURL(blob), a = document.createElement('a');
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
  return true;
}

/* ---------- Ekle / Düzenle ---------- */
let sh = null;
const wrap = $('#sheetWrap');
const toMin = t => { if (!/^\d{1,2}:\d{2}$/.test(t || '')) return null; const [h, m] = t.split(':').map(Number); return h * 60 + m; };
const effMode = () => sh.kind === 'leave' ? 'dur' : sh.mode;
function calc() {
  if (effMode() === 'dur') return (parseInt($('#sH').value, 10) || 0) * 60 + (parseInt($('#sM').value, 10) || 0);
  const s = toMin($('#sS').value), e = toMin($('#sE').value);
  if (s === null || e === null) return 0;
  let d = e - s; if (d <= 0) d += 1440; return d;
}
function updPrev() {
  const m = calc(); let t = m > 0 ? `= ${dur(m)}` : 'Süre gir';
  if (m > 0 && sh.kind === 'ot' && M.moneyOn()) t += ` · brüt ${M.fmtMoney(m / 60 * M.hourlyAt($('#sD').value || M.today()) * (set().mult[sh.type] || 1))}`;
  $('#prev').textContent = t;
}
function applyKind() {
  const leave = sh.kind === 'leave';
  $('#shTitle').textContent = (sh.id ? 'Kaydı düzenle' : leave ? 'İzin kullan' : 'Mesai ekle');
  $('#modeWrap').classList.toggle('hidden', leave);
  $('#typeWrap').classList.toggle('hidden', leave);
  $('#durBox').classList.toggle('hidden', effMode() !== 'dur');
  $('#rangeBox').classList.toggle('hidden', effMode() !== 'range');
  document.querySelectorAll('#kindSeg button').forEach(b => b.classList.toggle('on', b.dataset.v === sh.kind));
  document.querySelectorAll('#modeSeg button').forEach(b => b.classList.toggle('on', b.dataset.v === sh.mode));
  updPrev();
}
function openSheet(id, opt = {}) {
  const r = id ? M.db.records.find(x => String(x.id) === String(id)) : null;
  const d = r ? r.date : (opt.date || (st.month === M.today().slice(0, 7) ? M.today() : st.month + '-01'));
  const kind = r ? r.kind : (opt.kind || 'ot'), range = !!(r && r.start && r.end);
  sh = { id: r ? r.id : null, kind, mode: range ? 'range' : (opt.mode || 'dur'), type: r ? r.type : M.autoType(d), touched: !!r, fromTimer: !!opt.fromTimer };
  const h = r ? Math.floor(r.minutes / 60) : '', mm = r ? r.minutes % 60 : '';
  const tags = M.tagList().slice(0, 6);
  const presets = set().presets.slice().sort((a, b) => a - b);
  const kindSeg = set().bank || kind === 'leave' || (r && r.kind === 'leave') || M.leaves().length
    ? `<div class="seg wide" id="kindSeg" style="margin-bottom:6px"><button data-act="kind" data-v="ot">Mesai</button><button data-act="kind" data-v="leave">İzin kullanımı</button></div>` : '<div id="kindSeg"></div>';
  wrap.innerHTML = `<div class="sheet" role="dialog" aria-label="Kayıt"><div class="grab"></div>
    <h2 id="shTitle"></h2>${kindSeg}
    <label class="fl" for="sD">Tarih</label><input class="in" id="sD" type="date" value="${d}"><div class="holnote" id="holnote"></div>
    <div id="modeWrap"><label class="fl">Giriş yöntemi</label>
      <div class="seg wide" id="modeSeg"><button data-act="mode" data-v="dur">Süre</button><button data-act="mode" data-v="range">Başlangıç – Bitiş</button></div></div>
    <div id="durBox"><label class="fl">Süre</label>
      <div class="hm"><input class="in" id="sH" type="number" inputmode="numeric" min="0" max="24" placeholder="0" value="${h}"><span class="u">sa</span><input class="in" id="sM" type="number" inputmode="numeric" min="0" max="59" placeholder="0" value="${mm}"><span class="u">dk</span></div>
      <div class="chips">${presets.map(p => `<button class="chip" data-act="preset" data-m="${p}">${dur(p)}</button>`).join('')}</div>
      <div class="chips" style="margin-top:6px"><button class="chip alt" data-act="adj" data-m="-15">−15 dk</button><button class="chip alt" data-act="adj" data-m="15">+15 dk</button><button class="chip alt" data-act="adj" data-m="30">+30 dk</button><button class="chip alt" data-act="preset" data-m="0">Sıfırla</button></div></div>
    <div id="rangeBox"><div class="two"><div><label class="fl" for="sS">Başlangıç</label><input class="in" id="sS" type="time" value="${esc(r ? r.start : (opt.start || ''))}"></div><div><label class="fl" for="sE">Bitiş</label><input class="in" id="sE" type="time" value="${esc(r ? r.end : (opt.end || ''))}"></div></div></div>
    <div class="prev" id="prev"></div>
    <div id="typeWrap"><label class="fl">Gün türü</label>
      <div class="chips" id="types" style="margin-top:0">${Object.entries(TYPES).map(([k, v]) => `<button class="chip ${sh.type === k ? 'on' : ''}" data-act="type" data-v="${k}">${v}</button>`).join('')}</div></div>
    <label class="fl" for="sT">Etiket / proje (isteğe bağlı)</label><input class="in" id="sT" type="text" maxlength="30" placeholder="Örn. Stok sayımı, Depo" value="${esc(r ? r.tag : '')}" autocomplete="off">
    ${tags.length ? `<div class="chips">${tags.map(t => `<button class="chip alt" data-act="tagpick" data-t="${esc(t)}">#${esc(t)}</button>`).join('')}</div>` : ''}
    <label class="fl" for="sN">Not (isteğe bağlı)</label><input class="in" id="sN" type="text" maxlength="200" placeholder="Açıklama" value="${esc(r ? r.note : '')}">
    <button class="btn pri" data-act="save">Kaydet</button>
    ${r ? '<button class="btn dng" data-act="del">Kaydı sil</button>' : ''}
    <button class="btn out" data-act="close" style="margin-top:10px">Vazgeç</button></div>`;
  wrap.classList.add('open'); wrap.setAttribute('aria-hidden', 'false'); applyKind(); updHol();
}
function closeSheet() { wrap.classList.remove('open'); wrap.setAttribute('aria-hidden', 'true'); sh = null; simple = null; bk = null; }
function updHol() {
  const el = $('#holnote'); if (!el || !sh) return;
  const v = $('#sD').value, h = v && M.holidayInfo(v);
  if (!h) { el.textContent = ''; el.classList.remove('on'); return; }
  el.classList.add('on');
  el.textContent = `🎌 ${h.name}${h.half ? ' (yarım gün)' : ''} — ` + (M.isHolidayPay(v) ? `tatil çarpanı uygulanır (×${set().mult.holiday})` : 'normal gün sayılır');
}
function saveSheet() {
  const date = $('#sD').value, minutes = calc();
  if (!date) return toast('Lütfen tarih seç');
  if (minutes <= 0) return toast('Süreyi gir');
  if (minutes > 1440) return toast('Süre 24 saati aşamaz');
  const rng = effMode() === 'range';
  const rec = { id: sh.id || M.uid(), date, minutes, kind: sh.kind, type: sh.kind === 'leave' ? 'normal' : sh.type,
    note: $('#sN').value.trim(), tag: $('#sT').value.trim(), start: rng ? $('#sS').value : '', end: rng ? $('#sE').value : '' };
  if (sh.id) M.db.records = M.db.records.map(x => String(x.id) === String(sh.id) ? rec : x); else M.db.records.push(rec);
  if (sh.fromTimer) M.timer.clear();
  M.persist(); st.month = date.slice(0, 7); st.year = Number(date.slice(0, 4));
  if (st.view === 'cal' && st.selDay) st.selDay = date;
  closeSheet(); M.render(); toast('Kaydedildi ✓');
}
function quickAdd(m) {
  const d = M.today(), rec = { id: M.uid(), date: d, minutes: m, kind: 'ot', type: M.autoType(d), note: '', tag: '', start: '', end: '' };
  M.db.records.push(rec); M.persist(); st.month = d.slice(0, 7); M.render();
  toast(`Bugüne +${dur(m)} eklendi`, { label: 'Geri al', fn: () => { M.db.records = M.db.records.filter(x => x.id !== rec.id); M.persist(); M.render(); } });
}

/* ---------- Basit alt sayfalar: maaş/zam, özel tatil, toplu giriş ---------- */
let simple = null, bk = null;
function simpleSheet(title, body, onSave) {
  simple = onSave; sh = null;
  wrap.innerHTML = `<div class="sheet" role="dialog" aria-label="${esc(title)}"><div class="grab"></div><h2>${esc(title)}</h2>${body}<button class="btn pri" data-act="simplesave">Kaydet</button><button class="btn out" data-act="close" style="margin-top:10px">Vazgeç</button></div>`;
  wrap.classList.add('open'); wrap.setAttribute('aria-hidden', 'false');
}
function openRaise() {
  simpleSheet('Zam / maaş değişikliği', `<label class="fl" for="rMonth">Geçerli olduğu ay</label><input class="in" id="rMonth" type="month" value="${M.today().slice(0, 7)}"><label class="fl" for="rAmt">Yeni brüt aylık maaş</label><input class="in" id="rAmt" type="number" inputmode="decimal" min="0" placeholder="0"><p class="note">Bu aydan itibaren yapılan mesailer yeni maaşa göre hesaplanır; önceki aylar değişmez.</p>`, () => {
    const from = $('#rMonth').value, amount = num($('#rAmt').value);
    if (!/^\d{4}-\d{2}$/.test(from)) return toast('Ay seç');
    if (amount <= 0) return toast('Maaşı gir');
    const l = set().salaries.filter(e => e.from !== from); l.push({ from, amount }); l.sort((a, b) => a.from.localeCompare(b.from));
    set().salaries = l; M.persist(); closeSheet(); M.render(); toast('Maaş kaydedildi');
  });
}
function openHoliday() {
  simpleSheet('Özel tatil günü', `<label class="fl" for="hDate">Tarih</label><input class="in" id="hDate" type="date" value="${M.today()}"><label class="fl" for="hName">Ad</label><input class="in" id="hName" type="text" maxlength="40" placeholder="Örn. İdari izin, köprü günü"><p class="note">Bu günde yapılan mesai resmi tatil çarpanıyla hesaplanır.</p>`, () => {
    const date = $('#hDate').value, name = $('#hName').value.trim() || 'Özel tatil';
    if (!date) return toast('Tarih seç');
    set().customHolidays = set().customHolidays.filter(h => h.date !== date).concat({ date, name }).sort((a, b) => a.date.localeCompare(b.date));
    M.persist(); closeSheet(); M.render(); toast('Tatil günü eklendi');
  });
}
const bulkMin = () => (parseInt($('#bH').value, 10) || 0) * 60 + (parseInt($('#bM').value, 10) || 0);
function bulkDates() {
  const from = $('#bFrom').value, to = $('#bTo').value;
  if (!from || !to || to < from) return [];
  const have = new Set(M.ot().map(r => r.date)), out = [], end = M.parse(to);
  for (let d = M.parse(from), n = 0; d <= end && n < 400; d.setDate(d.getDate() + 1), n++) {
    const iso = M.iso(d);
    if (!bk.days.includes(d.getDay())) continue;
    const hol = M.holidayInfo(iso);
    if (bk.skipHol && hol && !hol.half) continue;
    if (bk.skipEx && have.has(iso)) continue;
    out.push(iso);
  }
  return out;
}
function updBulk() {
  if (!bk) return;
  const ds = bulkDates(), m = bulkMin();
  let t = ds.length && m > 0 ? `${ds.length} gün × ${dur(m)} = ${dur(ds.length * m)}` : 'Gün ve süre seç';
  if (ds.length && m > 0 && M.moneyOn()) t += ' · ' + M.fmtMoney(ds.reduce((a, d) => a + m / 60 * M.hourlyAt(d) * (set().mult[M.autoType(d)] || 1), 0));
  $('#bprev').textContent = t;
}
function openBulk() {
  const ws = set().weekStart, mon = M.parse(M.weekStartOf(M.today())), fri = new Date(mon);
  fri.setDate(fri.getDate() + (ws === 1 ? 4 : 5));
  bk = { days: [1, 2, 3, 4, 5], skipHol: true, skipEx: true };
  const order = [...Array(7)].map((_, i) => (i + ws) % 7);
  simpleSheet('Toplu giriş', `<p class="note" style="margin-top:0">Aynı süreyi birden fazla güne tek seferde ekle (ör. bu hafta her gün 1 saat).</p>
    <div class="two"><div><label class="fl" for="bFrom">Başlangıç</label><input class="in" id="bFrom" type="date" value="${M.iso(mon)}"></div><div><label class="fl" for="bTo">Bitiş</label><input class="in" id="bTo" type="date" value="${M.iso(fri)}"></div></div>
    <label class="fl">Günler</label><div class="chips" style="margin-top:0">${order.map(di => `<button class="chip ${bk.days.includes(di) ? 'on' : ''}" data-act="bday" data-v="${di}">${M.DAYS_S[di]}</button>`).join('')}</div>
    <label class="fl">Her gün için süre</label><div class="hm"><input class="in" id="bH" type="number" inputmode="numeric" min="0" max="24" placeholder="0"><span class="u">sa</span><input class="in" id="bM" type="number" inputmode="numeric" min="0" max="59" placeholder="0"><span class="u">dk</span></div>
    <div class="chips">${set().presets.slice().sort((a, b) => a - b).map(p => `<button class="chip" data-act="bpreset" data-m="${p}">${dur(p)}</button>`).join('')}</div>
    <label class="fl" for="bT">Etiket (isteğe bağlı)</label><input class="in" id="bT" type="text" maxlength="30" placeholder="Örn. Sayım dönemi" autocomplete="off">
    <div class="chips"><button class="chip on" data-act="bskiphol">Resmi tatilleri atla</button><button class="chip on" data-act="bskipex">Kaydı olan günleri atla</button></div>
    <div class="prev" id="bprev"></div>`, () => {
    const ds = bulkDates(), m = bulkMin();
    if (!ds.length) return toast('Eklenecek gün yok');
    if (m <= 0) return toast('Süreyi gir');
    if (m > 1440) return toast('Süre 24 saati aşamaz');
    const tag = $('#bT').value.trim(), recs = ds.map(date => ({ id: M.uid(), date, minutes: m, kind: 'ot', type: M.autoType(date), note: '', tag, start: '', end: '' }));
    M.db.records.push(...recs); M.persist(); st.month = ds[0].slice(0, 7); st.year = Number(st.month.slice(0, 4)); closeSheet(); M.render();
    const ids = new Set(recs.map(r => r.id));
    toast(`${recs.length} gün eklendi`, { label: 'Geri al', fn: () => { M.db.records = M.db.records.filter(r => !ids.has(r.id)); M.persist(); M.render(); } });
  });
  updBulk();
}

/* ---------- Sayaç ---------- */
function tick() {
  const t = M.timer.get(), pill = $('#tpill');
  if (!t) { pill.classList.add('hidden'); return; }
  const c = M.clock(Date.now() - t.start);
  pill.textContent = '● ' + c + ' · Bitir'; pill.classList.remove('hidden');
  const el = $('#tmr'); if (el) el.textContent = c;
}
function refreshPay() { const c = $('.calc'); if (c && M.moneyOn()) c.outerHTML = M.calcBox(); else M.render(); }

/* ---------- Dışa aktarma ---------- */
const scopeRecs = scope => {
  const rs = M.db.records.filter(r => scope === 'all' ? true : scope === 'year' ? r.date.slice(0, 4) === String(st.year) : r.date.slice(0, 7) === st.month);
  return rs.slice().sort((a, b) => a.date.localeCompare(b.date));
};
function csv(scope) {
  const rs = scopeRecs(scope);
  if (!rs.length) return toast('Dışa aktarılacak kayıt yok');
  const money = M.moneyOn(), ot = rs.filter(r => r.kind !== 'leave'), lv = rs.filter(r => r.kind === 'leave');
  const head = ['Tarih', 'Gün', 'Kayıt', 'Başlangıç', 'Bitiş', 'Süre (sa:dk)', 'Toplam dakika', 'Gün türü', 'Etiket', ...(money ? ['Brüt kazanç'] : []), 'Not'];
  const rows = [head, ...rs.map(r => [pretty(r.date), DAYS[parse(r.date).getDay()], r.kind === 'leave' ? 'İzin' : 'Mesai', r.start, r.end, hm(r.minutes), r.minutes,
    r.kind === 'leave' ? '' : TYPES[r.type], r.tag, ...(money ? [r.kind === 'leave' ? '' : Math.round(M.earn(r) * 100) / 100] : []), r.note])];
  const blank = n => Array(n).fill('');
  rows.push([ 'TOPLAM MESAİ', ...blank(4), hm(M.sum(ot)), M.sum(ot), '', '', ...(money ? [Math.round(ot.reduce((a, r) => a + M.earn(r), 0) * 100) / 100] : []), '']);
  if (lv.length) rows.push(['TOPLAM İZİN', ...blank(4), hm(M.sum(lv)), M.sum(lv), '', '', ...(money ? [''] : []), '']);
  const pay = M.payOf(rs);
  if (pay) { const r2 = n => Math.round(n * 100) / 100, line = (l, v) => [l, ...blank(8), r2(v), '']; rows.push(line('KESİNTİLER (tahmini: SGK+işsizlik, gelir v., damga)', -pay.ded), line('NET (ELE GEÇEN) MESAİ ÜCRETİ (tahmini)', pay.net)); }
  const text = '﻿' + rows.map(r => r.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(';')).join('\r\n');
  outFile({ all: 'erdem-mesai-tumu.csv', year: `erdem-mesai-${st.year}.csv`, month: `erdem-mesai-${st.month}.csv` }[scope], 'text/csv;charset=utf-8', text);
}
const whoText = () => { const p = set().profile; return [p.name && `Ad Soyad: ${p.name}`, p.empNo && `Sicil No: ${p.empNo}`, p.company && `İşyeri: ${p.company}`].filter(Boolean).join('   ·   '); };
const signModel = () => { const p = set().profile; return { left: 'Çalışan' + (p.name ? ': ' + p.name : ''), right: 'Yönetici onayı' + (p.manager ? ': ' + p.manager : ''), date: `Hazırlanma tarihi: ${pretty(M.today())}` }; };
async function savePdf(name, model) {
  toast('PDF hazırlanıyor…');
  await new Promise(r => setTimeout(r, 60));
  let bytes;
  try { bytes = M.pdfReport(model); } catch (e) { return toast('PDF oluşturulamadı'); }
  await outFile(name, 'application/pdf', bytes);
}
function printReport(kind) {
  const money = M.moneyOn(), mult = set().mult;
  if (kind === 'month') {
    const s = M.monthStats(st.month), rs = scopeRecs('month');
    if (!rs.length) return toast('Bu ay için kayıt yok');
    const hr = M.hourlyAt(st.month + '-15');
    const cols = money
      ? [{ h: 'Tarih', w: .145 }, { h: 'Gün', w: .145 }, { h: 'Tür', w: .135 }, { h: 'Etiket / Not', w: .34 }, { h: 'Süre', w: .09, align: 'right' }, { h: 'Brüt ücret', w: .145, align: 'right' }]
      : [{ h: 'Tarih', w: .16 }, { h: 'Gün', w: .16 }, { h: 'Tür', w: .15 }, { h: 'Etiket / Not', w: .39 }, { h: 'Süre', w: .14, align: 'right' }];
    const rows = rs.map(r => { const lv = r.kind === 'leave', h = !lv && r.type === 'holiday' && M.holidayInfo(r.date);
      return [pretty(r.date), DAYS[parse(r.date).getDay()], lv ? 'İzin' : TYPES[r.type], [h && h.name, r.tag && '#' + r.tag, r.note].filter(Boolean).join(' · '), (lv ? '−' : '') + hm(r.minutes), ...(money ? [lv ? '' : M.fmtMoney(M.earn(r))] : [])]; });
    const tables = [{ cols, rows, foot: { label: 'Toplam mesai', vals: money ? { 4: hm(s.total), 5: M.fmtMoney(s.money) } : { 4: hm(s.total) } } }];
    if (money) tables.push({ title: 'Ücret hesabı', cols: [{ h: 'Mesai türü', w: .28 }, { h: 'Süre', w: .18, align: 'right' }, { h: 'Çarpan', w: .14, align: 'right' }, { h: 'Saatlik ücret', w: .2, align: 'right' }, { h: 'Tutar (brüt)', w: .2, align: 'right' }],
      rows: Object.keys(TYPES).filter(k => s.byType[k]).map(k => [TYPES[k], dur(s.byType[k]), '×' + mult[k], M.fmtMoney2(hr), M.fmtMoney(s.moneyBy[k])]),
      foot: { label: 'Toplam brüt mesai ücreti', vals: { 4: M.fmtMoney(s.money) } } });
    if (money && s.pay) tables.push({ title: 'Net (ele geçen) hesabı — tahmini', cols: [{ h: 'Kalem', w: .7 }, { h: 'Tutar', w: .3, align: 'right' }],
      rows: [['Brüt mesai ücreti', M.fmtMoney2(s.money)], ['SGK işçi payı + işsizlik (%15)', '−' + M.fmtMoney2(s.pay.sgk)], ['Gelir vergisi', '−' + M.fmtMoney2(s.pay.tax)], ['Damga vergisi', '−' + M.fmtMoney2(s.pay.dv)]],
      foot: { label: 'Net (ele geçen) mesai ücreti', vals: { 1: M.fmtMoney2(s.net) } } });
    savePdf(`erdem-mesai-rapor-${st.month}.pdf`, { title: 'Fazla Mesai Raporu', sub: `${MONTHS[s.m - 1]} ${s.y}`, who: whoText(),
      stats: [{ v: dur(s.total), l: 'Toplam mesai' }, { v: String(s.days), l: 'Mesai günü' }, ...(s.pay ? [] : [{ v: dur(s.avg), l: 'Günlük ort.' }]), ...(money ? [{ v: M.fmtMoney(s.money), l: 'Brüt ücret' }, ...(s.pay ? [{ v: M.fmtMoney(s.net), l: 'Net ücret' }] : [])] : [])],
      tables, notes: money ? [`Saatlik ücret = brüt maaş ÷ ${set().divisor} saat.` + (s.pay ? ' Net tutar tahminidir: yıl içi kümülatif gelir vergisi dilimi, SGK/işsizlik, damga vergisi ve asgari ücret istisnası hesaba katılmıştır; mesai maaşa eklenince oluşan fark gösterilir. Kesin tutar bordrodadır.' : ' Tutarlar brüttür; kesintiler dahil değildir.')] : [], sign: signModel(), footer: 'Erdem Mesai Takip' });
  } else {
    const ys = M.yearStats(st.year);
    if (!ys.total) return toast('Bu yıl için kayıt yok');
    const cols = money ? (ys.pays ? [{ h: 'Ay', w: .28 }, { h: 'Gün', w: .12, align: 'right' }, { h: 'Süre', w: .2, align: 'right' }, { h: 'Brüt ücret', w: .2, align: 'right' }, { h: 'Net ücret', w: .2, align: 'right' }] : [{ h: 'Ay', w: .34 }, { h: 'Gün', w: .16, align: 'right' }, { h: 'Süre', w: .25, align: 'right' }, { h: 'Brüt ücret', w: .25, align: 'right' }]) : [{ h: 'Ay', w: .4 }, { h: 'Gün', w: .25, align: 'right' }, { h: 'Süre', w: .35, align: 'right' }];
    const rows = ys.months.map((m, i) => [MONTHS[i], m.days ? String(m.days) : '', m.total ? dur(m.total) : '—', ...(money ? [m.total ? M.fmtMoney(m.money) : '', ...(ys.pays ? [m.total ? M.fmtMoney(m.net) : ''] : [])] : [])]);
    const foot = { label: 'Toplam', vals: money ? { 1: String(ys.days), 2: dur(ys.total), 3: M.fmtMoney(ys.money), ...(ys.pays ? { 4: M.fmtMoney(ys.net) } : {}) } : { 1: String(ys.days), 2: dur(ys.total) } };
    savePdf(`erdem-mesai-rapor-${st.year}.pdf`, { title: 'Yıllık Fazla Mesai Raporu', sub: String(st.year), who: whoText(),
      stats: [{ v: dur(ys.total), l: 'Toplam mesai' }, { v: String(ys.days), l: 'Mesai günü' }, ...(ys.pays ? [] : [{ v: dur(ys.avg), l: 'Aylık ort.' }]), ...(money ? [{ v: M.fmtMoney(ys.money), l: 'Brüt ücret' }, ...(ys.pays ? [{ v: M.fmtMoney(ys.net), l: 'Net ücret' }] : [])] : [])],
      tables: [{ cols, rows, foot }], notes: money ? [ys.pays ? 'Net tutarlar tahminidir: kümülatif gelir vergisi dilimi, SGK/işsizlik, damga vergisi ve asgari ücret istisnası hesaba katılmıştır. Kesin tutar bordrodadır.' : 'Tutarlar brüttür; kesintiler dahil değildir.'] : [], sign: signModel(), footer: 'Erdem Mesai Takip' });
  }
}
function xlsx(scope) {
  const rs = scopeRecs(scope);
  if (!rs.length) return toast('Dışa aktarılacak kayıt yok');
  const money = M.moneyOn(), mult = set().mult, H = t => ({ t, s: 1 });
  const head = ['Tarih', 'Gün', 'Kayıt', 'Başlangıç', 'Bitiş', 'Süre', 'Dakika', 'Gün türü', 'Çarpan', 'Etiket', ...(money ? ['Saatlik ücret', 'Brüt ücret'] : []), 'Not'].map(H);
  const rows = [head];
  rs.forEach(r => {
    const lv = r.kind === 'leave';
    rows.push([{ n: M.xlsxDate(r.date), s: 2 }, DAYS[parse(r.date).getDay()], lv ? 'İzin' : 'Mesai', r.start, r.end, { n: r.minutes / 1440, s: 3 }, r.minutes, lv ? '' : TYPES[r.type], lv ? '' : mult[r.type], r.tag,
      ...(money ? [lv ? '' : { n: Math.round(M.hourlyAt(r.date) * 100) / 100, s: 4 }, lv ? '' : { n: Math.round(M.earn(r) * 100) / 100, s: 4 }] : []), r.note]);
  });
  const last = rows.length, otr = rs.filter(r => r.kind !== 'leave'), lvr = rs.filter(r => r.kind === 'leave');
  const mc = money ? 'L' : null, moneySum = Math.round(otr.reduce((a, r) => a + M.earn(r), 0) * 100) / 100;
  const tot = (label, crit, list, withMoney) => {
    const row = Array(head.length).fill(''); row[0] = { t: label, s: 5 };
    for (let i = 1; i < head.length; i++) row[i] = { t: '', s: 5 };
    row[5] = { f: `SUMIF(C2:C${last},"${crit}",F2:F${last})`, v: M.sum(list) / 1440, s: 6 };
    row[6] = { f: `SUMIF(C2:C${last},"${crit}",G2:G${last})`, v: M.sum(list), s: 5 };
    if (money && withMoney) row[11] = { f: `SUMIF(C2:C${last},"${crit}",${mc}2:${mc}${last})`, v: moneySum, s: 7 };
    return row;
  };
  rows.push(tot('TOPLAM MESAİ', 'Mesai', otr, true));
  if (lvr.length) rows.push(tot('TOPLAM İZİN', 'İzin', lvr, false));
  const widths = [12, 12, 8, 10, 10, 9, 9, 13, 8, 16, ...(money ? [13, 14] : []), 36];
  const sheets = [{ name: 'Kayıtlar', rows, widths, freeze: 1 }];
  const p = set().profile, period = scope === 'year' ? String(st.year) : `${MONTHS[Number(st.month.slice(5)) - 1]} ${st.month.slice(0, 4)}`;
  const sum = [[{ t: 'Erdem Mesai Takip', s: 8 }], ['Dönem', period]];
  if (p.name) sum.push(['Ad Soyad', p.name]); if (p.company) sum.push(['İşyeri', p.company]); if (p.empNo) sum.push(['Sicil No', p.empNo]);
  sum.push(['Toplam mesai (sa:dk)', { f: `'Kayıtlar'!F${last + 1}`, v: M.sum(otr) / 1440, s: 3 }], ['Mesai günü', new Set(otr.map(r => r.date)).size]);
  if (money) {
    sum.push(['Brüt mesai ücreti', { f: `'Kayıtlar'!L${last + 1}`, v: moneySum, s: 4 }], ['', ''], [H('Mesai türü'), H('Süre'), H('Çarpan'), H('Tutar (brüt)')]);
    Object.keys(TYPES).forEach(k => { const sub = otr.filter(r => r.type === k); if (sub.length) sum.push([TYPES[k], { n: M.sum(sub) / 1440, s: 3 }, mult[k], { n: Math.round(sub.reduce((a, r) => a + M.earn(r), 0) * 100) / 100, s: 4 }]); });
    const pay = M.payOf(rs), r2 = n => Math.round(n * 100) / 100;
    if (pay) { sum.push(['', ''], [{ t: 'Net (ele geçen) hesabı — tahmini', s: 5 }, { t: '', s: 5 }], ['Brüt mesai ücreti', { n: moneySum, s: 4 }], ['SGK işçi payı + işsizlik', { n: -r2(pay.sgk), s: 4 }], ['Gelir vergisi', { n: -r2(pay.tax), s: 4 }], ['Damga vergisi', { n: -r2(pay.dv), s: 4 }], [{ t: 'NET MESAİ ÜCRETİ', s: 5 }, { f: `SUM(B${sum.length + 3}:B${sum.length + 6})`, v: r2(pay.net), s: 7 }], ['Net tutar tahminidir (kümülatif vergi dilimi, asgari ücret istisnası dahil).']); }
    else sum.push(['Tutarlar brüttür; kesintiler dahil değildir.']);
  }
  sheets.push({ name: 'Özet', rows: sum, widths: [26, 18, 10, 16] });
  if (scope === 'year') {
    const ys = M.yearStats(st.year), mrows = [['Ay', 'Mesai günü', 'Süre', ...(money ? ['Brüt ücret', ...(ys.pays ? ['Net ücret (tahmini)'] : [])] : [])].map(H)];
    ys.months.forEach((m, i) => mrows.push([MONTHS[i], m.days || '', { n: m.total / 1440, s: 3 }, ...(money ? [{ n: Math.round(m.money * 100) / 100, s: 4 }, ...(ys.pays ? [{ n: Math.round(m.net * 100) / 100, s: 4 }] : [])] : [])]));
    mrows.push([{ t: 'TOPLAM', s: 5 }, { f: 'SUM(B2:B13)', v: ys.months.reduce((a, m) => a + m.days, 0), s: 5 }, { f: 'SUM(C2:C13)', v: ys.total / 1440, s: 6 }, ...(money ? [{ f: 'SUM(D2:D13)', v: Math.round(ys.money * 100) / 100, s: 7 }, ...(ys.pays ? [{ f: 'SUM(E2:E13)', v: Math.round(ys.net * 100) / 100, s: 7 }] : [])] : [])]);
    sheets.push({ name: 'Aylık', rows: mrows, widths: [14, 12, 12, 16, 20], freeze: 1 });
  }
  outFile(`erdem-mesai-${scope === 'year' ? st.year : st.month}.xlsx`, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', M.makeXlsx(sheets));
}
async function shareSummary() {
  const s = M.monthStats(st.month);
  const text = `${MONTHS[s.m - 1]} ${s.y} fazla mesai: ${dur(s.total)} · ${s.days} gün · günlük ort. ${dur(s.avg)}` + (M.moneyOn() ? ` · brüt ${M.fmtMoney(s.money)}` + (s.pay ? ` · net ≈ ${M.fmtMoney(s.net)}` : '') : '');
  try { if (navigator.share) { await navigator.share({ text }); return; } } catch (e) { if (e && e.name === 'AbortError') return; }
  try { await navigator.clipboard.writeText(text); toast('Özet panoya kopyalandı'); } catch (e) { toast(text); }
}
async function backup() {
  const { pin, salt, hint, lastBackup, ...rest } = set();
  const ok = await outFile(`erdem-mesai-yedek-${M.today()}.json`, 'application/json',
    JSON.stringify({ app: 'mesai-takip', version: 5, exported: new Date().toISOString(), settings: rest, records: M.db.records }, null, 2));
  if (ok) { set().lastBackup = new Date().toISOString(); M.persist(); M.render(); }
}
async function restoreFrom(file) {
  try {
    const p = JSON.parse(await file.text()), arr = Array.isArray(p) ? p : p.records;
    if (!Array.isArray(arr)) throw 0;
    const list = arr.map(M.norm).filter(Boolean);
    if (!list.length) throw 0;
    if (!confirm(`Yedekte ${list.length} kayıt var. Mevcut kayıtların yanına eklensin mi? (Aynı kayıtlar tekrarlanmaz)`)) return;
    const sig = r => `${r.date}|${r.minutes}|${r.kind}|${r.note}`, have = new Set(M.db.records.map(sig)), ids = new Set(M.db.records.map(r => r.id));
    let added = 0;
    list.forEach(r => { if (have.has(sig(r))) return; if (ids.has(r.id)) r.id = M.uid(); M.db.records.push(r); have.add(sig(r)); added++; });
    if (!Array.isArray(p) && p.settings && confirm('Yedekteki ayarlar (hedef, ücret, şablonlar…) da uygulansın mı?')) {
      const keep = { pin: set().pin, salt: set().salt, hint: set().hint, lastBackup: set().lastBackup };
      M.db.settings = { ...M.mergeSettings(p.settings), ...keep };
    }
    M.persist(); M.render(); toast(`${added} kayıt eklendi`);
  } catch (e) { toast('Geçerli bir yedek dosyası değil'); }
}

/* ---------- PIN kilidi ---------- */
async function sha(s) {
  if (window.crypto && crypto.subtle) { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)); return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join(''); }
  let h = 5381; for (const c of s) h = ((h << 5) + h + c.charCodeAt(0)) | 0; return 'x' + h;
}
let lk = { mode: 'unlock', buf: '', first: '' }, hiddenAt = 0;
$('#pad').innerHTML = [1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => `<button data-k="${n}">${n}</button>`).join('') + `<button class="ph"></button><button data-k="0">0</button><button data-k="x" aria-label="Sil">⌫</button>`;
function showLock(mode) {
  lk = { mode, buf: '', first: '' };
  const T = { unlock: 'PIN gir', set1: 'Yeni PIN belirle', set2: 'PIN\'i tekrar gir', off: 'Kapatmak için PIN gir' };
  $('#lockTitle').textContent = T[mode]; $('#lockMsg').textContent = '';
  const alt = $('#lockAlt'); alt.textContent = mode === 'unlock' ? 'PIN\'imi unuttum' : 'Vazgeç'; alt.dataset.m = mode;
  $('#lock').classList.remove('hidden'); dots();
}
function dots() { document.querySelectorAll('#dots i').forEach((d, i) => d.classList.toggle('f', i < lk.buf.length)); }
function bad(msg) { const d = $('#dots'); $('#lockMsg').textContent = msg; d.classList.remove('shake'); void d.offsetWidth; d.classList.add('shake'); lk.buf = ''; setTimeout(dots, 250); }
async function lockKey(k) {
  if (k === 'x') lk.buf = lk.buf.slice(0, -1); else if (lk.buf.length < 4) lk.buf += k;
  dots(); if (lk.buf.length < 4) return;
  const pin = lk.buf, s = set();
  if (lk.mode === 'unlock') { if (await sha(s.salt + pin) === s.pin) { $('#lock').classList.add('hidden'); lk.buf = ''; } else bad('Yanlış PIN'); }
  else if (lk.mode === 'off') { if (await sha(s.salt + pin) === s.pin) { s.pin = null; s.salt = null; M.persist(); $('#lock').classList.add('hidden'); M.render(); toast('PIN kapatıldı'); } else bad('Yanlış PIN'); }
  else if (lk.mode === 'set1') { lk.first = pin; lk.buf = ''; lk.mode = 'set2'; $('#lockTitle').textContent = 'PIN\'i tekrar gir'; $('#lockMsg').textContent = ''; setTimeout(dots, 150); }
  else if (lk.mode === 'set2') {
    if (pin === lk.first) { s.salt = M.uid(); s.pin = await sha(s.salt + pin); M.persist(); $('#lock').classList.add('hidden'); M.render(); toast('PIN açıldı 🔒'); }
    else { showLock('set1'); $('#lockMsg').textContent = 'PIN\'ler eşleşmedi, tekrar dene'; }
  }
}
$('#pad').addEventListener('click', e => { const b = e.target.closest('[data-k]'); if (b) lockKey(b.dataset.k); });
$('#lockAlt').addEventListener('click', e => {
  if (e.currentTarget.dataset.m === 'unlock') {
    if (confirm('PIN\'i sıfırlamak için tüm kayıtlar silinir. Devam edilsin mi?')) { M.resetDb(); M.persist(); $('#lock').classList.add('hidden'); M.render(); toast('Sıfırlandı'); }
  } else $('#lock').classList.add('hidden');
});
document.addEventListener('visibilitychange', () => {
  if (document.hidden) hiddenAt = Date.now();
  else if (set().pin && hiddenAt && Date.now() - hiddenAt > 30000) showLock('unlock');
});

/* ---------- Eylemler ---------- */
const go = (view, patch = {}) => { Object.assign(st, patch, { view }); M.render(); };
const A = {
  tab(el) { st.view = el.dataset.v; M.render(); },
  prev() { st.month = M.addMonths(st.month, -1); st.selDay = null; st.year = Number(st.month.slice(0, 4)); M.render(); },
  next() { st.month = M.addMonths(st.month, 1); st.selDay = null; st.year = Number(st.month.slice(0, 4)); M.render(); },
  thismonth() { st.month = M.today().slice(0, 7); st.selDay = null; M.render(); },
  prevy() { st.year--; M.render(); }, nexty() { st.year++; M.render(); },
  thisyear() { st.year = new Date().getFullYear(); M.render(); },
  gomonth(el) { st.month = el.dataset.m; st.year = Number(st.month.slice(0, 4)); st.selDay = null; go('home'); $('#screen').scrollTop = 0; },
  gotoday(el) { st.month = el.dataset.d.slice(0, 7); st.year = Number(st.month.slice(0, 4)); go('cal', { selDay: el.dataset.d, calMode: 'cal' }); $('#screen').scrollTop = 0; },
  day(el) { st.selDay = st.selDay === el.dataset.d ? null : el.dataset.d; M.render(); },
  addday(el) { openSheet(null, { date: el.dataset.d }); },
  seelist() { go('cal', { calMode: 'list', selDay: null }); $('#screen').scrollTop = 0; },
  calmode(el) { st.calMode = el.dataset.v; M.render(); },
  filter(el) { st.filter = el.dataset.v; M.render(); },
  add() { openSheet(null, { date: st.view === 'cal' && st.selDay ? st.selDay : undefined }); },
  addleave() { openSheet(null, { kind: 'leave' }); },
  edit(el) { openSheet(el.dataset.id); }, close() { closeSheet(); },
  kind(el) { sh.kind = el.dataset.v; applyKind(); },
  mode(el) { sh.mode = el.dataset.v; applyKind(); },
  preset(el) { const t = +el.dataset.m; $('#sH').value = t ? Math.floor(t / 60) : ''; $('#sM').value = t ? t % 60 : ''; updPrev(); },
  adj(el) { const t = Math.max(0, Math.min(1440, calc() + (+el.dataset.m))); $('#sH').value = t ? Math.floor(t / 60) : ''; $('#sM').value = t ? t % 60 : ''; updPrev(); },
  type(el) { sh.type = el.dataset.v; sh.touched = true; document.querySelectorAll('#types .chip').forEach(b => b.classList.toggle('on', b === el)); updPrev(); },
  tagpick(el) { $('#sT').value = el.dataset.t; },
  save() { saveSheet(); },
  del() {
    const rec = M.db.records.find(x => String(x.id) === String(sh.id)); if (!rec) return;
    M.db.records = M.db.records.filter(x => x !== rec); M.persist(); closeSheet(); M.render();
    toast('Kayıt silindi', { label: 'Geri al', fn: () => { M.db.records.push(rec); M.persist(); M.render(); } });
  },
  quick(el) { quickAdd(+el.dataset.m); },
  theme(el) { set().theme = el.dataset.v; M.persist(); M.render(); },
  wstart(el) { set().weekStart = +el.dataset.v; M.persist(); M.render(); },
  bank(el) { set().bank = el.dataset.v === '1'; M.persist(); M.render(); },
  pin() { showLock(set().pin ? 'off' : 'set1'); },
  addpreset() {
    const v = prompt('Şablon süresi (sa:dk). Örn. 1:30 veya dakika olarak 90', '1:30'); if (v === null) return;
    const m = M.parseHM(v); if (!m || m > 1440) return toast('Geçerli bir süre gir');
    if (!set().presets.includes(m)) { if (set().presets.length >= 8) return toast('En fazla 8 şablon'); set().presets.push(m); M.persist(); }
    M.render();
  },
  delpreset(el) { set().presets = set().presets.filter(p => p !== +el.dataset.m); M.persist(); M.render(); },
  csvMonth() { csv('month'); }, csvYear() { csv('year'); }, csvAll() { csv('all'); },
  printMonth() { printReport('month'); }, printYear() { printReport('year'); },
  share() { shareSummary(); }, backup() { backup(); }, restore() { $('#restoreFile').click(); },
  wipe() { if (confirm('TÜM kayıtlar kalıcı olarak silinecek. Emin misin?') && confirm('Son onay: bu işlem geri alınamaz.')) { M.db.records = []; M.persist(); M.render(); toast('Tüm kayıtlar silindi'); } },
  hint() { set().hint = true; M.persist(); M.render(); },
  tstart() { M.timer.start(); M.render(); toast('Sayaç başladı'); },
  tstop() {
    const t = M.timer.get(); if (!t) return;
    const a = new Date(t.start), b = new Date();
    if (b - a < 60000) { M.timer.clear(); M.render(); return toast('1 dakikadan kısa, kaydedilmedi'); }
    const mins = Math.round((b - a) / 60000), sm = a.getHours() * 60 + a.getMinutes(), em = (sm + mins) % 1440, f = n => `${pad(Math.floor(n / 60))}:${pad(n % 60)}`;
    openSheet(null, { date: M.iso(a), mode: 'range', start: f(sm), end: f(em), fromTimer: true });
  },
  tcancel() { if (confirm('Sayaç iptal edilsin mi? Süre kaydedilmez.')) { M.timer.clear(); M.render(); } },
  bulk() { openBulk(); },
  bday(el) { const d = +el.dataset.v; bk.days = bk.days.includes(d) ? bk.days.filter(x => x !== d) : bk.days.concat(d); el.classList.toggle('on'); updBulk(); },
  bskiphol(el) { bk.skipHol = !bk.skipHol; el.classList.toggle('on'); updBulk(); },
  bskipex(el) { bk.skipEx = !bk.skipEx; el.classList.toggle('on'); updBulk(); },
  bpreset(el) { const t = +el.dataset.m; $('#bH').value = t ? Math.floor(t / 60) : ''; $('#bM').value = t ? t % 60 : ''; updBulk(); },
  simplesave() { if (simple) simple(); },
  raise() { openRaise(); },
  delraise(el) { if (set().salaries.length > 1) { set().salaries.splice(+el.dataset.i, 1); M.persist(); M.render(); } },
  addhol() { openHoliday(); },
  delhol(el) { set().customHolidays.splice(+el.dataset.i, 1); M.persist(); M.render(); },
  arife(el) { set().arife = el.dataset.v === '1'; M.persist(); M.render(); },
  netOn(el) { set().net.on = el.dataset.v === '1'; M.persist(); M.render(); },
  netSgk(el) { set().net.sgk = el.dataset.v === '1'; M.persist(); M.render(); },
  netEx(el) { set().net.exempt = el.dataset.v === '1'; M.persist(); M.render(); },
  applyhol() {
    const list = M.ot().filter(r => r.type !== 'holiday' && M.isHolidayPay(r.date));
    if (!list.length || !confirm(`${list.length} kayıt resmi tatil olarak güncellensin mi? (tatil çarpanı uygulanır)`)) return;
    list.forEach(r => { r.type = 'holiday'; }); M.persist(); M.render(); toast(`${list.length} kayıt güncellendi`);
  },
  xlsxMonth() { xlsx('month'); }, xlsxYear() { xlsx('year'); }
};
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (el && A[el.dataset.act]) { A[el.dataset.act](el); return; }
  if (e.target === wrap) closeSheet();
});
document.addEventListener('input', e => {
  const id = e.target.id;
  if (id === 'q') { st.q = e.target.value; $('#rows').innerHTML = M.listRows(); }
  else if (sh && ['sH', 'sM', 'sS', 'sE'].includes(id)) updPrev();
  else if (bk && ['bH', 'bM', 'bFrom', 'bTo'].includes(id)) updBulk();
});
document.addEventListener('change', e => {
  const id = e.target.id, v = e.target.value, s = set();
  if (id === 'sD' && sh) { updHol(); updPrev(); }
  const saved = () => { M.persist(); toast('Kaydedildi'); };
  if (id === 'goal') { s.goal = num(v); saved(); }
  else if (id === 'ylim') { s.yearLimit = num(v); saved(); }
  else if (id === 'wage') { s.wage = num(v); saved(); }
  else if (id === 'mN') { s.mult.normal = num(v) || 1; saved(); }
  else if (id === 'mW') { s.mult.weekend = num(v) || 1; saved(); }
  else if (id === 'mH') { s.mult.holiday = num(v) || 1; saved(); }
  else if (id === 'cur') { s.cur = v.trim().slice(0, 4) || '₺'; saved(); }
  else if (id === 'salary') {
    const n = num(v);
    if (n > 0) { if (!s.salaries.length) s.salaries.push({ from: '2000-01', amount: n }); else s.salaries[s.salaries.length - 1].amount = n; saved(); }
    else if (s.salaries.length === 1) { s.salaries = []; saved(); }
    else toast('Birden fazla maaş kaydı var; silmek için ×');
  }
  else if (id === 'divisor') { s.divisor = num(v) || 225; saved(); }
  else if (id === 'pfName') { s.profile.name = v.trim(); saved(); }
  else if (id === 'pfCompany') { s.profile.company = v.trim(); saved(); }
  else if (id === 'pfEmp') { s.profile.empNo = v.trim(); saved(); }
  else if (id === 'pfMgr') { s.profile.manager = v.trim(); saved(); }
  else if (id === 'sD' && sh && !sh.touched && v) {
    sh.type = M.autoType(v);
    document.querySelectorAll('#types .chip').forEach(b => b.classList.toggle('on', b.dataset.v === sh.type)); updPrev();
  } else if (id === 'restoreFile') { const f = e.target.files[0]; if (f) restoreFrom(f); e.target.value = ''; }
  if (['wage', 'mN', 'mW', 'mH', 'salary', 'divisor'].includes(id)) refreshPay();
});

/* ---------- Başlangıç ---------- */
const render0 = M.render;
M.render = () => { render0(); tick(); };
M.render();
setInterval(tick, 1000);
if (set().pin) showLock('unlock');
if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) navigator.serviceWorker.register('sw.js').catch(() => {});
})();
