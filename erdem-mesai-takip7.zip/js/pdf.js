'use strict';
/* Bağımlılıksız rapor PDF'i: sayfalar canvas'a çizilir, JPEG olarak PDF'e gömülür.
   (iPhone ana ekran uygulamalarında window.print() çalışmadığı için gerçek dosya üretilir.) */
(() => {
const W = 1240, H = 1754, MX = 90, MT = 96, MB = 120, CW = W - 2 * MX;   // A4, 150 dpi
const FONT = '"Helvetica Neue", Helvetica, Arial, sans-serif';

function drawReport(m) {
  const pages = []; let pg = null, y = 0;
  const txt = (s, x, yy, o = {}) => {
    const c = pg.x; c.font = `${o.weight || 400} ${o.size || 24}px ${FONT}`; c.fillStyle = o.color || '#111'; c.textAlign = o.align || 'left';
    s = String(s == null ? '' : s);
    if (o.maxW && c.measureText(s).width > o.maxW) { while (s.length > 1 && c.measureText(s + '…').width > o.maxW) s = s.slice(0, -1); s += '…'; }
    c.fillText(s, x, yy);
  };
  const hline = (yy, color, w) => { const c = pg.x; c.fillStyle = color; c.fillRect(MX, yy, CW, w || 1.5); };
  const rr = (x, yy, w, h, r, fill, stroke) => {
    const c = pg.x; c.beginPath(); c.moveTo(x + r, yy); c.arcTo(x + w, yy, x + w, yy + h, r); c.arcTo(x + w, yy + h, x, yy + h, r); c.arcTo(x, yy + h, x, yy, r); c.arcTo(x, yy, x + w, yy, r); c.closePath();
    c.fillStyle = fill; c.fill(); if (stroke) { c.strokeStyle = stroke; c.lineWidth = 2; c.stroke(); }
  };
  const newPage = first => {
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, W, H); x.textBaseline = 'alphabetic';
    pg = { c, x }; pages.push(pg); y = MT;
    if (!first) { txt(`${m.title} · ${m.sub}`, MX, y + 22, { size: 22, color: '#666' }); y += 54; }
  };
  const ensure = h => { if (y + h > H - MB) newPage(false); };

  newPage(true);
  txt(m.title, MX, y + 40, { size: 52, weight: 800, color: '#0f3d2e' }); y += 64;
  txt(m.sub, MX, y + 24, { size: 28, color: '#555' }); y += 46;
  if (m.who) { txt(m.who, MX, y + 22, { size: 24, color: '#222', maxW: CW }); y += 44; } else y += 8;

  if (m.stats && m.stats.length) {
    const n = m.stats.length, gap = 18, bw = (CW - gap * (n - 1)) / n, bh = 112;
    m.stats.forEach((s, i) => {
      const x0 = MX + i * (bw + gap);
      rr(x0, y, bw, bh, 16, '#eef6f1', '#cfe0d6');
      txt(s.v, x0 + 20, y + 54, { size: 34, weight: 800, color: '#0f3d2e', maxW: bw - 40 });
      txt(s.l, x0 + 20, y + 90, { size: 22, color: '#667', maxW: bw - 40 });
    });
    y += bh + 36;
  }

  (m.tables || []).forEach(t => {
    if (t.title) { ensure(130); txt(t.title, MX, y + 30, { size: 28, weight: 700 }); y += 52; }
    const widths = t.cols.map(c => c.w * CW), xs = []; let acc = MX; widths.forEach(w => { xs.push(acc); acc += w; });
    const RH = 46, PAD = 12;
    const cell = (s, i, yy, o) => { const right = t.cols[i].align === 'right'; txt(s, right ? xs[i] + widths[i] - PAD : xs[i] + PAD, yy + 31, { ...o, align: right ? 'right' : 'left', maxW: widths[i] - 2 * PAD }); };
    const head = () => { ensure(RH * 2); pg.x.fillStyle = '#eef3f0'; pg.x.fillRect(MX, y, CW, RH); t.cols.forEach((c, i) => cell(c.h, i, y, { weight: 700, size: 22 })); y += RH; };
    head();
    t.rows.forEach(r => {
      if (y + RH > H - MB) { newPage(false); head(); }
      r.forEach((s, i) => cell(s, i, y, { size: 23 })); hline(y + RH, '#d6d6d6'); y += RH;
    });
    if (t.foot) {
      ensure(RH + 10); hline(y, '#111', 3); pg.x.fillStyle = '#f2f7f4'; pg.x.fillRect(MX, y + 3, CW, RH);
      const idx = Object.keys(t.foot.vals).map(Number), first = Math.min(...idx);
      txt(t.foot.label, MX + PAD, y + 34, { weight: 800, size: 24, maxW: xs[first] - MX - 2 * PAD });
      idx.forEach(i => cell(t.foot.vals[i], i, y + 3, { weight: 800, size: 24 }));
      y += RH + 3;
    }
    y += 34;
  });

  (m.notes || []).forEach(n => {
    const c = pg.x; c.font = `400 22px ${FONT}`; const words = String(n).split(' '); let line = '';
    const out = []; words.forEach(w => { const t = line ? line + ' ' + w : w; if (c.measureText(t).width > CW && line) { out.push(line); line = w; } else line = t; }); out.push(line);
    ensure(out.length * 32 + 10); out.forEach(l => { txt(l, MX, y + 22, { size: 22, color: '#555' }); y += 32; }); y += 10;
  });

  if (m.sign) {
    ensure(230); y += 80;
    const bw = 440; pg.x.fillStyle = '#111';
    pg.x.fillRect(MX, y, bw, 2); pg.x.fillRect(MX + CW - bw, y, bw, 2);
    txt(m.sign.left, MX, y + 38, { size: 23, color: '#333', maxW: bw });
    txt(m.sign.right, MX + CW - bw, y + 38, { size: 23, color: '#333', maxW: bw });
    y += 100; if (m.sign.date) txt(m.sign.date, MX, y, { size: 22, color: '#666' });
  }

  pages.forEach((p, i) => { pg = p; txt(`${m.footer} · Sayfa ${i + 1}/${pages.length}`, W / 2, H - 56, { size: 20, color: '#888', align: 'center' }); });
  return pages.map(p => p.c);
}

function jpegBytes(c) {
  const bin = atob(c.toDataURL('image/jpeg', 0.92).split(',')[1]), u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return u;
}

function buildPdf(jpegs) {
  const enc = new TextEncoder(), parts = [], offs = []; let off = 0;
  const push = b => { const u = typeof b === 'string' ? enc.encode(b) : b; parts.push(u); off += u.length; };
  const obj = (n, body) => { offs[n] = off; push(`${n} 0 obj\n`); body(); push('\nendobj\n'); };
  const n = jpegs.length, kids = jpegs.map((_, i) => `${5 + 3 * i} 0 R`).join(' ');
  push('%PDF-1.4\n');
  obj(1, () => push('<< /Type /Catalog /Pages 2 0 R >>'));
  obj(2, () => push(`<< /Type /Pages /Kids [${kids}] /Count ${n} >>`));
  jpegs.forEach((j, i) => {
    const img = 3 + 3 * i, con = 4 + 3 * i, pge = 5 + 3 * i, cs = 'q 595.28 0 0 841.89 0 0 cm /Im0 Do Q';
    obj(img, () => { push(`<< /Type /XObject /Subtype /Image /Width ${W} /Height ${H} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${j.length} >>\nstream\n`); push(j); push('\nendstream'); });
    obj(con, () => push(`<< /Length ${cs.length} >>\nstream\n${cs}\nendstream`));
    obj(pge, () => push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /Im0 ${img} 0 R >> >> /Contents ${con} 0 R >>`));
  });
  const total = 3 + 3 * n, xref = off;
  push(`xref\n0 ${total}\n0000000000 65535 f \n`);
  for (let i = 1; i < total; i++) push(`${String(offs[i]).padStart(10, '0')} 00000 n \n`);
  push(`trailer\n<< /Size ${total} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`);
  const res = new Uint8Array(off); let p = 0; parts.forEach(b => { res.set(b, p); p += b.length; });
  return res;
}

M.pdfReport = model => buildPdf(drawReport(model).map(jpegBytes));
})();
