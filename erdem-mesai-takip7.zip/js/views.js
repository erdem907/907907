'use strict';
/* Görünümler: Özet, Takvim/Liste, Yıl, Ayarlar */
(() => {
const { MONTHS, MONTHS_S, DAYS, DAYS_S, TYPES, TCOL, esc, dur, hm, pad, parse, pretty } = M;
const st = M.state;
const settings = () => M.db.settings;

/* ---------- ortak parçalar ---------- */
const monthBar = () => {
  const [y, m] = st.month.split('-').map(Number);
  return `<div class="mbar"><button class="ib" data-act="prev" aria-label="Önceki ay">‹</button><button class="mtitle" data-act="thismonth" aria-label="Bu aya dön">${MONTHS[m - 1]} ${y}</button><button class="ib" data-act="next" aria-label="Sonraki ay">›</button></div>`;
};
const yearBar = () => `<div class="mbar"><button class="ib" data-act="prevy" aria-label="Önceki yıl">‹</button><button class="mtitle" data-act="thisyear">${st.year}</button><button class="ib" data-act="nexty" aria-label="Sonraki yıl">›</button></div>`;

const hbars = (items, opt = {}) => {
  const max = Math.max(1, ...items.map(i => i.min));
  return items.map(i => `<div class="hb"><div class="hl">${esc(i.label)}</div><div class="hbar"><i style="width:${(i.min / max * 100).toFixed(1)}%;background:${i.color || 'var(--brand2)'}"></i></div><div class="hv">${i.min ? dur(i.min) : '—'}</div></div>`).join('');
};
const kv = rows => rows.map(([k, v]) => `<div class="kv"><span>${k}</span><b>${v}</b></div>`).join('');

const rowHtml = r => {
  const d = parse(r.date), leave = r.kind === 'leave';
  const tags = (leave ? '<span class="tag leave">İzin</span>' : (r.type !== 'normal' ? `<span class="tag ${r.type}">${TYPES[r.type]}</span>` : ''))
    + (r.tag ? `<span class="tag tg">#${esc(r.tag)}</span>` : '');
  const range = r.start && r.end ? `${esc(r.start)} – ${esc(r.end)}` : '';
  const money = !leave && M.moneyOn() ? ` · ${M.fmtMoney(M.earn(r))}` : '';
  return `<button class="row" data-act="edit" data-id="${esc(r.id)}">
    <div class="dbox${leave ? ' lv' : ''}"><b>${d.getDate()}</b><span>${DAYS_S[d.getDay()]}</span></div>
    <div class="rmid"><div class="t">${DAYS[d.getDay()]}${tags}</div><div class="n">${esc(r.note || range || (leave ? 'İzin kullanımı' : 'Not yok'))}</div></div>
    <div class="rright"><b class="${leave ? 'neg' : ''}">${leave ? '−' : ''}${hm(r.minutes)}</b><span>${dur(r.minutes)}${money}</span></div></button>`;
};
const emptyMsg = t => `<div class="empty">${t}</div>`;

/* ---------- ÖZET ---------- */
const homeV = () => {
  const s = M.monthStats(st.month), set = settings(), db = M.db;
  const [y, m] = st.month.split('-').map(Number);
  const prev = M.monthStats(M.addMonths(st.month, -1));
  const isCur = st.month === M.today().slice(0, 7);

  /* uyarılar */
  let banners = '';
  if (M.isIOS && !M.standalone() && !set.hint) banners += `<div class="banner"><span>📲</span><div>Ana ekrana eklemek için Safari'de <b>Paylaş → Ana Ekrana Ekle</b> seçeneğini kullan.</div><button data-act="hint" aria-label="Kapat">×</button></div>`;
  const lastB = set.lastBackup ? M.dayNum(set.lastBackup.slice(0, 10)) : null;
  if (db.records.length >= 5 && (lastB === null || M.dayNum(M.today()) - lastB > 30))
    banners += `<div class="banner warn"><span>💾</span><div>${lastB === null ? 'Henüz yedek almadın.' : 'Son yedeğin 30 günden eski.'} Verilerini korumak için yedekle.</div><button class="bb" data-act="backup">Yedekle</button></div>`;
  if (!db.records.length) banners += `<div class="banner"><span>👋</span><div><b>Hoş geldin!</b> Alttaki <b>+</b> ile ilk fazla mesaini ekle. Aylık toplam, takvim ve yıllık rapor otomatik oluşur.</div></div>`;

  /* ana kart */
  let delta = '';
  if (prev.total > 0) {
    const d = s.total - prev.total;
    delta = `<div class="delta ${d > 0 ? 'up' : d < 0 ? 'down' : ''}">${d > 0 ? '▲' : d < 0 ? '▼' : '＝'} ${d === 0 ? 'Geçen ayla aynı' : dur(Math.abs(d)) + (d > 0 ? ' daha fazla' : ' daha az')} <span>· geçen ay ${dur(prev.total)}</span></div>`;
  }
  const third = `<div><b>${hm(s.total)}</b><span>sa:dk</span></div>`;
  const earnBlock = M.moneyOn() ? `<div class="earn"><div><span>Brüt mesai ücreti</span><b>${M.fmtMoney(s.money)}</b></div>${s.pay ? `<div class="nt"><span>Net (ele geçen)</span><b>${M.fmtMoney(s.net)}</b></div>` : ''}<div class="er"><span>saatlik (brüt)</span><b>${M.fmtMoney2(M.hourlyAt(st.month + '-15'))}</b></div></div>` : '';
  const hero = `<div class="card hero"><div class="k">${MONTHS[m - 1]} ${y} · toplam fazla mesai</div>
    <div class="big">${dur(s.total)}</div>${earnBlock}${delta}
    <div class="trio"><div><b>${s.days}</b><span>mesai günü</span></div><div><b>${dur(s.avg)}</b><span>günlük ort.</span></div>${third}</div></div>`;

  /* hedef */
  const goal = set.goal * 60, pct = goal ? Math.min(s.total / goal, 1) : 0, R = 46, C = 2 * Math.PI * R;
  let goalCard;
  if (goal) {
    const left = goal - s.total, dl = isCur ? s.n - new Date().getDate() + 1 : 0;
    const need = left > 0 && dl > 0 ? `<div class="k">Günde ~${dur(Math.ceil(left / dl))} gerekir <span>(${dl} gün kaldı)</span></div>` : '';
    goalCard = `<div class="card"><div class="ringwrap"><div class="ring sm"><svg width="116" height="116" viewBox="0 0 116 116"><circle cx="58" cy="58" r="${R}" fill="none" stroke="var(--mint)" stroke-width="11"/><circle cx="58" cy="58" r="${R}" fill="none" stroke="${left <= 0 ? 'var(--t2)' : 'var(--brand2)'}" stroke-width="11" stroke-linecap="round" stroke-dasharray="${C.toFixed(1)}" stroke-dashoffset="${(C * (1 - pct)).toFixed(1)}"/></svg><div class="c"><b>${Math.round(s.total / goal * 100)}%</b><span>hedef</span></div></div>
      <div class="rside"><div class="k">Aylık hedef</div><div class="v">${dur(goal)}</div><div class="k">${left <= 0 ? 'Hedef aşıldı: +' + dur(-left) : 'Kalan: ' + dur(left)}</div>${need}</div></div></div>`;
  } else goalCard = `<div class="card cta"><div><div class="l">Aylık hedef belirle</div><div class="s">İlerlemeni halka ile takip et</div></div><button class="link" data-act="tab" data-v="set">Ayarla ›</button></div>`;

  /* hızlı ekle */
  const quick = `<div class="card"><h3>Bugüne hızlı ekle</h3><div class="chips" style="margin-top:0">${set.presets.slice().sort((a, b) => a - b).map(p => `<button class="chip" data-act="quick" data-m="${p}">+${dur(p)}</button>`).join('')}<button class="chip alt" data-act="add">Özel…</button></div></div>`;

  /* haftalar */
  const weeks = s.weeks.map((v, i) => {
    const a = Math.max(1, i * 7 - s.first + 1), b = Math.min(s.n, (i + 1) * 7 - s.first);
    return { label: `${a}–${b} ${MONTHS_S[m - 1]}`, min: v };
  });
  const weeksCard = `<div class="card"><h3>Haftalara göre</h3>${hbars(weeks)}</div>`;

  /* tür dağılımı */
  let typeCard = '';
  if (s.total > 0) {
    const seg = Object.keys(TYPES).filter(k => s.byType[k] > 0).map(k => `<i style="width:${(s.byType[k] / s.total * 100).toFixed(2)}%;background:${TCOL[k]}"></i>`).join('');
    const leg = Object.keys(TYPES).map(k => `<div class="lg"><span class="dot" style="background:${TCOL[k]}"></span><span class="ln">${TYPES[k]}</span><b>${dur(s.byType[k])}</b><span class="lp">${Math.round(s.byType[k] / s.total * 100)}%</span></div>`).join('');
    typeCard = `<div class="card"><h3>Mesai türü dağılımı</h3><div class="stack">${seg}</div>${leg}</div>`;
  }

  /* günlük grafik */
  const mh = Math.max(s.max, 60), today = M.today();
  let bars = '';
  for (let i = 1; i <= s.n; i++) {
    const key = `${st.month}-${pad(i)}`, v = s.perDay[key] || 0, bw = 300 / s.n, h = v ? Math.max(4, v / mh * 66) : 2;
    const x = ((i - 1) * bw + bw * .14).toFixed(1), w = (bw * .72).toFixed(1);
    bars += `<rect x="${x}" y="${(74 - h).toFixed(1)}" width="${w}" height="${h.toFixed(1)}" rx="2" fill="${v ? (key === today ? 'var(--brand)' : 'var(--brand2)') : 'var(--line)'}"/>`;
    if (v) bars += `<rect x="${((i - 1) * bw).toFixed(1)}" y="0" width="${bw.toFixed(1)}" height="76" fill="transparent" data-act="gotoday" data-d="${key}"/>`;
  }
  const mid = Math.ceil(s.n / 2);
  const dayCard = `<div class="card"><h3>Günlere göre dağılım</h3><svg class="chart" viewBox="0 0 300 92">${s.max ? `<text x="0" y="7">${hm(s.max)}</text>` : ''}<line x1="0" y1="75" x2="300" y2="75" stroke="var(--line)"/>${bars}<text x="0" y="89">1</text><text x="${((mid - .5) * 300 / s.n).toFixed(0)}" y="89" text-anchor="middle">${mid}</text><text x="300" y="89" text-anchor="end">${s.n}</text></svg></div>`;

  /* içgörüler */
  const rows = [
    ['En yoğun gün', s.maxDate ? `${parse(s.maxDate).getDate()} ${MONTHS_S[m - 1]} · ${dur(s.max)}` : '—'],
    ['Mesai yapılan gün', `${s.days} / ${s.n}`],
    ['En uzun seri (tüm zamanlar)', `${M.streak()} gün`],
    ['Tüm zamanlar toplamı', dur(M.sum(M.ot()))]
  ];
  const tagTop = Object.entries(s.byTag).sort((a, b) => b[1] - a[1])[0];
  if (tagTop) rows.splice(2, 0, ['En çok etiket', `#${esc(tagTop[0])} · ${dur(tagTop[1])}`]);
  if (M.moneyOn()) rows.push(['Tüm zamanlar kazanç', M.fmtMoney(M.ot().reduce((a, r) => a + M.earn(r), 0))]);
  const insightCard = `<div class="card"><h3>Özet bilgiler</h3>${kv(rows)}</div>`;

  /* bakiye */
  let bankCard = '';
  if (set.bank) {
    const b = M.bank();
    bankCard = `<div class="card bank"><div class="k">Mesai bakiyesi (kullanılabilir izin)</div><div class="big ${b < 0 ? 'neg' : ''}">${b < 0 ? '−' : ''}${dur(Math.abs(b))}</div><div class="k">Toplam mesai ${dur(M.sum(M.ot()))} − kullanılan izin ${dur(M.sum(M.leaves()))}</div><button class="btn soft" data-act="addleave" style="margin-top:12px">İzin kullan</button></div>`;
  }

  /* yıllık sınır */
  let limitCard = '';
  if (set.yearLimit > 0) {
    const ys = M.yearStats(y), lim = set.yearLimit * 60, p = ys.total / lim;
    limitCard = `<div class="card"><div class="more"><h3 style="margin:0">${y} yıllık sınır</h3><span class="count">${dur(ys.total)} / ${set.yearLimit} sa</span></div><div class="bar-h ${p >= 1 ? 'over' : p >= .9 ? 'warn' : ''}"><i style="width:${Math.min(p * 100, 100).toFixed(1)}%"></i></div><p class="note">${p >= 1 ? 'Yıllık sınırı aştın.' : 'Kalan: ' + dur(lim - ys.total) + (p >= .9 ? ' — sınıra yaklaşıyorsun.' : '')} Sınırı Ayarlar'dan değiştirebilirsin.</p></div>`;
  }

  const recent = M.byDate(db.records.filter(r => r.date.slice(0, 7) === st.month)).slice(0, 4);
  const recentCard = `<div class="card"><div class="more"><h3 style="margin:0">Son kayıtlar</h3><button class="link" data-act="seelist">Tümü ›</button></div>${recent.length ? recent.map(rowHtml).join('') : emptyMsg('Bu ay için kayıt yok.')}</div>`;

  /* ücret dökümü */
  const hr = M.hourlyAt(st.month + '-15');
  const payCta = M.moneyOn() ? '' : `<div class="card cta"><div><div class="l">💰 Mesai ücretini hesapla</div><div class="s">Brüt maaşını gir; saatlik ücret ve kazancın otomatik çıksın</div></div><button class="link" data-act="tab" data-v="set">Gir ›</button></div>`;
  let payCard = '';
  if (M.moneyOn()) {
    const prow = Object.keys(TYPES).filter(k => s.byType[k] > 0).map(k => `<div class="pr"><div><b>${TYPES[k]}</b><span>${dur(s.byType[k])} × ${set.mult[k]} × ${M.fmtMoney2(hr)}</span></div><b>${M.fmtMoney(s.moneyBy[k])}</b></div>`).join('');
    const src = set.salaries.length ? `Maaş ${M.fmtMoney(M.salaryAt(st.month))} ÷ ${set.divisor} sa = ${M.fmtMoney2(hr)}/sa` : `Saatlik ücret ${M.fmtMoney2(hr)}`;
    const np = s.pay && s.money > 0 ? `<div class="pr"><div><b>Kesintiler</b><span>SGK+işsizlik ${M.fmtMoney(s.pay.sgk)} · gelir vergisi ${M.fmtMoney(s.pay.tax)} · damga ${M.fmtMoney(s.pay.dv)}</span></div><b class="neg">−${M.fmtMoney(s.pay.ded)}</b></div><div class="pr tot net"><div><b>Net (ele geçen)</b><span>tahmini · bordroda maaşına eklenen kısım</span></div><b>${M.fmtMoney(s.net)}</b></div>` : '';
    const nnote = s.pay ? `Net, yıl içi kümülatif vergi dilimine göre <b>tahmini</b>dir (mesai, maaşın üstüne eklenince oluşan fark). ${M.netEstimated(s.y) ? s.y + ' için ' + (s.y > 2026 ? '2026' : '2025') + ' parametreleri kullanıldı. ' : ''}Kesinti ayarları: Ayarlar → Net hesabı.` : (M.db.settings.net.on ? 'Net (ele geçen) tutarı için Ayarlar’dan brüt aylık maaşını gir.' : 'Brüt tutardır; kesintiler dahil değildir.');
    payCard = `<div class="card"><h3>Mesai ücreti dökümü</h3>${prow || emptyMsg('Bu ay mesai yok.')}<div class="pr tot"><div><b>Brüt toplam</b><span>${src}</span></div><b>${M.fmtMoney(s.money)}</b></div>${np}<p class="note">${nnote}</p></div>`;
  }
  /* sayaç */
  const tm = M.timer.get();
  const timerCard = tm
    ? `<div class="card timer run"><div><div class="k">● Mesai sayacı çalışıyor</div><div class="tt" id="tmr">${M.clock(Date.now() - tm.start)}</div><div class="k">${pad(new Date(tm.start).getHours())}:${pad(new Date(tm.start).getMinutes())}'den beri</div></div><div class="tb"><button class="btn pri sm" data-act="tstop">■ Bitir</button><button class="link" data-act="tcancel">İptal</button></div></div>`
    : `<div class="card timer"><div><div class="l">Mesaiye mi kalıyorsun?</div><div class="s">Başlat; bitirince süre otomatik kaydedilir</div></div><button class="btn pri sm" data-act="tstart">▶ Başlat</button></div>`;
  /* bu hafta */
  const wk = M.weekStats(), wmx = Math.max(60, ...wk.days.map(d => d.min)), tdy = M.today(), wdiff = wk.total - wk.prev;
  const weekCard = `<div class="card"><div class="more"><h3 style="margin:0">Bu hafta</h3><span class="count">${dur(wk.total)}</span></div><div class="wk">${wk.days.map(d => `<div class="wc${d.date === tdy ? ' td' : ''}"><em>${d.min ? hm(d.min) : ''}</em><i style="height:${d.min ? Math.max(6, d.min / wmx * 54).toFixed(0) : 3}px"></i><span>${DAYS_S[parse(d.date).getDay()]}</span></div>`).join('')}</div><p class="note">Geçen hafta ${dur(wk.prev)} · ${wdiff === 0 ? 'aynı' : (wdiff > 0 ? '▲ ' + dur(wdiff) + ' daha fazla' : '▼ ' + dur(-wdiff) + ' daha az')}${M.streakCurrent() >= 2 ? ' · 🔥 ' + M.streakCurrent() + ' gün seri' : ''}</p></div>`;
  /* yaklaşan tatiller */
  const ups = M.upcomingHolidays(tdy, 4);
  const holCard = ups.length ? `<div class="card"><h3>Yaklaşan resmi tatiller</h3>${ups.map(h => { const dn = M.dayNum(h.date) - M.dayNum(tdy), d = parse(h.date); return `<div class="kv hol"><span><b>${d.getDate()} ${MONTHS_S[d.getMonth()]}</b> ${DAYS[d.getDay()]}</span><b>${esc(h.name)}${h.half ? ' (yarım gün)' : ''}${h.est ? ' *' : ''}<em>${dn === 0 ? 'bugün' : dn + ' gün sonra'}</em></b></div>`; }).join('')}${ups.some(h => h.est) ? '<p class="note">* Tarih tahminidir; Diyanet takvimi açıklanınca 1 gün farklı olabilir.</p>' : ''}</div>` : '';

  return `<div class="hdr"><div class="brand">Kişisel takip</div><h1>Erdem Mesai Takip</h1>${monthBar()}</div>${banners}${hero}${payCta}${timerCard}${goalCard}${quick}${payCard}${weekCard}${weeksCard}${typeCard}${dayCard}${holCard}${insightCard}${bankCard}${limitCard}${recentCard}`;
};

/* ---------- TAKVİM / LİSTE ---------- */
const filterChips = () => [['all', 'Tümü'], ['normal', 'Hafta içi'], ['weekend', 'Hafta sonu'], ['holiday', 'Tatil'], ['leave', 'İzin']]
  .map(([k, l]) => `<button class="chip ${st.filter === k ? 'on' : ''}" data-act="filter" data-v="${k}">${l}</button>`).join('');
const listRows = () => {
  const q = st.q.trim().toLocaleLowerCase('tr');
  let rs = M.db.records.filter(r => r.date.slice(0, 7) === st.month);
  if (st.filter === 'leave') rs = rs.filter(r => r.kind === 'leave');
  else if (st.filter !== 'all') rs = rs.filter(r => r.kind !== 'leave' && r.type === st.filter);
  if (q) rs = rs.filter(r => `${r.note} ${r.tag} ${DAYS[parse(r.date).getDay()]} ${TYPES[r.type]} ${pretty(r.date)}`.toLocaleLowerCase('tr').includes(q));
  rs = M.byDate(rs);
  return rs.length ? rs.map(rowHtml).join('') : emptyMsg(q || st.filter !== 'all' ? 'Eşleşen kayıt yok.' : 'Bu ay için kayıt yok.');
};
const calV = () => {
  const s = M.monthStats(st.month), ws = settings().weekStart, today = M.today();
  const leaveDays = new Set(M.leaves().filter(r => r.date.slice(0, 7) === st.month).map(r => r.date));
  const head = `<div class="hdr"><div class="brand">${st.calMode === 'cal' ? 'Takvim' : 'Kayıtlar'}</div><h1>${dur(s.total)}</h1><div class="sub">${s.days} gün mesai yapıldı${M.moneyOn() ? ' · brüt ' + M.fmtMoney(s.money) + (s.pay ? ' · net ' + M.fmtMoney(s.net) : '') : ''}</div>${monthBar()}</div>`;
  const seg = `<div class="seg wide" style="margin-top:14px"><button class="${st.calMode === 'cal' ? 'on' : ''}" data-act="calmode" data-v="cal">Takvim</button><button class="${st.calMode === 'list' ? 'on' : ''}" data-act="calmode" data-v="list">Liste</button></div>`;
  if (st.calMode === 'list') {
    return `${head}${seg}<input class="search" id="q" type="search" placeholder="Not, etiket veya gün ara…" value="${esc(st.q)}" autocomplete="off"><div class="chips scroll" id="fchips">${filterChips()}</div><div class="card" style="margin-top:10px;padding-top:6px;padding-bottom:6px" id="rows">${listRows()}</div>`;
  }
  const cap = Math.max(240, s.max);
  let cells = '';
  for (let i = 0; i < s.first; i++) cells += '<div class="cell e"></div>';
  for (let d = 1; d <= s.n; d++) {
    const key = `${st.month}-${pad(d)}`, v = s.perDay[key] || 0, r = v / cap;
    const lv = !v ? 0 : r < .25 ? 1 : r < .5 ? 2 : r < .75 ? 3 : 4;
    cells += `<button class="cell lv${lv}${key === today ? ' today' : ''}${key === st.selDay ? ' sel' : ''}${leaveDays.has(key) ? ' hl' : ''}${M.holidayInfo(key) ? ' hol' : ''}" data-act="day" data-d="${key}" aria-label="${d} ${MONTHS[s.m - 1]}"><span class="dn">${d}</span><span class="dv">${v ? hm(v) : ''}</span></button>`;
  }
  const mhol = M.holidaysOfYear(s.y).filter(h => h.date.slice(0, 7) === st.month);
  const hchips = mhol.length ? `<div class="hlist">${mhol.map(h => `<span><b>${Number(h.date.slice(8))}</b> ${esc(h.name)}${h.half ? ' (yarım)' : ''}${h.est ? '*' : ''}</span>`).join('')}</div>` : '';
  const wd = [...Array(7)].map((_, i) => `<div>${DAYS_S[(i + ws) % 7]}</div>`).join('');
  const grid = `<div class="card calcard"><div class="wd">${wd}</div><div class="grid7">${cells}</div>
    <div class="legend2"><span>az</span><i class="lv1"></i><i class="lv2"></i><i class="lv3"></i><i class="lv4"></i><span>çok</span><em>▪ izin · kırmızı gün = tatil</em></div>${hchips}<button class="link" data-act="bulk" style="width:100%;margin-top:4px">＋ Toplu giriş</button></div>`;
  let panel;
  if (st.selDay) {
    const rs = M.byDate(M.db.records.filter(r => r.date === st.selDay)), tot = M.sum(rs.filter(r => r.kind !== 'leave'));
    panel = `<div class="card"><div class="more"><h3 style="margin:0">${M.longDate(st.selDay)}${(() => { const h = M.holidayInfo(st.selDay); return h ? `<span class="tag holiday">${esc(h.name)}</span>` : ''; })()}</h3><span class="count">${tot ? dur(tot) : ''}</span></div>${rs.length ? rs.map(rowHtml).join('') : emptyMsg('Bu gün için kayıt yok.')}<button class="btn pri" data-act="addday" data-d="${st.selDay}" style="margin-top:12px">＋ Bu güne mesai ekle</button></div>`;
  } else {
    const rs = M.byDate(M.db.records.filter(r => r.date.slice(0, 7) === st.month));
    panel = `<div class="card"><div class="more"><h3 style="margin:0">${MONTHS[s.m - 1]} kayıtları</h3><span class="count">${rs.length} kayıt</span></div>${rs.length ? rs.map(rowHtml).join('') : emptyMsg('Bu ay için kayıt yok.<br>Bir güne dokunup ekleyebilirsin.')}</div>`;
  }
  return `${head}${seg}${grid}${panel}`;
};

/* ---------- YIL ---------- */
const yearV = () => {
  const y = st.year, ys = M.yearStats(y), set = settings(), ws = set.weekStart, curM = M.today().slice(0, 7);
  const hero = `<div class="card hero"><div class="k">${y} · yıllık toplam fazla mesai</div><div class="big">${dur(ys.total)}</div>${M.moneyOn() ? `<div class="earn"><div><span>Yıllık brüt mesai ücreti</span><b>${M.fmtMoney(ys.money)}</b></div>${ys.pays ? `<div class="nt"><span>Yıllık net (ele geçen)</span><b>${M.fmtMoney(ys.net)}</b></div>` : ''}</div>` : ''}
    <div class="trio"><div><b>${ys.days}</b><span>mesai günü</span></div><div><b>${dur(ys.avg)}</b><span>aylık ort.</span></div>${M.moneyOn() ? `<div><b>${M.fmtMoney(ys.pays ? ys.net : ys.money)}</b><span>${ys.pays ? 'net kazanç' : 'brüt kazanç'}</span></div>` : `<div><b>${ys.best >= 0 ? MONTHS_S[ys.best] : '—'}</b><span>en yoğun ay</span></div>`}</div></div>`;
  let limit = '';
  if (set.yearLimit > 0) {
    const lim = set.yearLimit * 60, p = ys.total / lim;
    limit = `<div class="card"><div class="more"><h3 style="margin:0">Yıllık sınır</h3><span class="count">${dur(ys.total)} / ${set.yearLimit} sa</span></div><div class="bar-h ${p >= 1 ? 'over' : p >= .9 ? 'warn' : ''}"><i style="width:${Math.min(p * 100, 100).toFixed(1)}%"></i></div><p class="note">${p >= 1 ? 'Sınır aşıldı.' : 'Kalan: ' + dur(lim - ys.total)}</p></div>`;
  }
  const mx = Math.max(60, ...ys.months.map(m => m.total));
  let bars = '';
  ys.months.forEach((mo, i) => {
    const bw = 300 / 12, h = mo.total ? Math.max(4, mo.total / mx * 78) : 2, x = i * bw, key = `${y}-${pad(i + 1)}`;
    bars += `<rect x="${(x + bw * .17).toFixed(1)}" y="${(96 - h).toFixed(1)}" width="${(bw * .66).toFixed(1)}" height="${h.toFixed(1)}" rx="3" fill="${mo.total ? (key === curM ? 'var(--brand)' : 'var(--brand2)') : 'var(--line)'}"/>`;
    if (mo.total) bars += `<text x="${(x + bw / 2).toFixed(1)}" y="${(92 - h).toFixed(1)}" text-anchor="middle" class="vl">${Math.round(mo.total / 6) / 10}</text>`;
    bars += `<text x="${(x + bw / 2).toFixed(1)}" y="110" text-anchor="middle">${MONTHS_S[i]}</text><rect x="${x.toFixed(1)}" y="0" width="${bw.toFixed(1)}" height="112" fill="transparent" data-act="gomonth" data-m="${key}"/>`;
  });
  const chart = `<div class="card"><div class="more"><h3 style="margin:0">Aylara göre (saat)</h3><span class="count">ay için dokun</span></div><svg class="chart" viewBox="0 0 300 114">${bars}</svg></div>`;
  const table = `<div class="card" style="padding-top:8px;padding-bottom:8px"><h3 style="margin-top:6px">Aylık döküm</h3>${ys.months.map((mo, i) => `<button class="mrow" data-act="gomonth" data-m="${y}-${pad(i + 1)}"><span class="mn">${MONTHS[i]}</span><span class="md">${mo.days ? mo.days + ' gün' : ''}</span><b>${mo.total ? dur(mo.total) : '—'}</b>${M.moneyOn() ? `<span class="mm">${mo.total ? M.fmtMoney(mo.money) + (ys.pays ? `<i>${M.fmtMoney(mo.net)}</i>` : '') : ''}</span>` : ''}</button>`).join('')}${ys.pays ? '<p class="note" style="margin:6px 0 2px">Sağ sütun: üstte brüt, altta <b>net</b> (ele geçen) mesai ücreti.</p>' : ''}</div>`;

  const days = Math.round((new Date(y + 1, 0, 1) - new Date(y, 0, 1)) / 864e5), off = (new Date(y, 0, 1).getDay() - ws + 7) % 7, cols = Math.ceil((days + off) / 7);
  let cellsSvg = '', lbl = '';
  for (let i = 0; i < days; i++) {
    const d = new Date(y, 0, 1 + i), key = M.iso(d), v = ys.heat[key] || 0, col = Math.floor((i + off) / 7), row = (i + off) % 7;
    const lv = !v ? 0 : v < 60 ? 1 : v < 120 ? 2 : v < 240 ? 3 : 4;
    cellsSvg += `<rect class="hm${lv}" x="${col * 7}" y="${12 + row * 7}" width="6" height="6" rx="1.4"${v ? ` data-act="gotoday" data-d="${key}"` : ''}/>`;
    if (d.getDate() === 1) lbl += `<text x="${col * 7}" y="8">${MONTHS_S[d.getMonth()]}</text>`;
  }
  const heat = `<div class="card"><h3>Yıl haritası</h3><div class="hscroll"><svg class="chart heat" viewBox="0 0 ${cols * 7} 61" style="min-width:${Math.max(300, cols * 7)}px">${lbl}${cellsSvg}</svg></div></div>`;

  const wdItems = [...Array(7)].map((_, i) => { const di = (i + ws) % 7; return { label: DAYS[di], min: ys.weekday[di], color: (di === 0 || di === 6) ? 'var(--t2)' : 'var(--brand2)' }; });
  const wdCard = `<div class="card"><h3>Haftanın günlerine göre</h3>${hbars(wdItems)}</div>`;
  let typeCard = '';
  if (ys.total) typeCard = `<div class="card"><h3>Mesai türüne göre</h3>${hbars(Object.keys(TYPES).map(k => ({ label: TYPES[k], min: ys.byType[k], color: TCOL[k] })))}</div>`;
  const tags = Object.entries(ys.byTag).sort((a, b) => b[1] - a[1]).slice(0, 8);
  const tagCard = tags.length ? `<div class="card"><h3>Etiketlere göre</h3>${hbars(tags.map(([t, v]) => ({ label: '#' + t, min: v })))}</div>` : '';
  const empty = ys.total ? '' : `<div class="card">${emptyMsg(`${y} yılı için kayıt yok.`)}</div>`;
  const hy = M.holidaysOfYear(y), worked = {};
  M.ot().forEach(r => { if (r.date.slice(0, 4) === String(y)) worked[r.date] = (worked[r.date] || 0) + r.minutes; });
  const wkdayHol = hy.filter(h => { const w = parse(h.date).getDay(); return !h.half && w !== 0 && w !== 6; }).length;
  const holCard = `<div class="card"><div class="more"><h3 style="margin:0">${y} resmi tatilleri</h3><span class="count">${hy.filter(h => !h.half).length} gün · ${wkdayHol} hafta içi</span></div>${hy.map(h => { const d = parse(h.date); return `<div class="kv hol"><span><b>${d.getDate()} ${MONTHS_S[d.getMonth()]}</b> ${DAYS_S[d.getDay()]}</span><b>${esc(h.name)}${h.half ? ' (yarım)' : ''}${h.est ? ' *' : ''}${worked[h.date] ? `<em>mesai: ${dur(worked[h.date])}</em>` : ''}</b></div>`; }).join('')}${hy.some(h => h.est) ? '<p class="note">* Tahmini tarih; Diyanet takvimi açıklanınca 1 gün farklı olabilir. Ayarlar → Resmi tatiller bölümünden özel gün ekleyebilirsin.</p>' : ''}</div>`;
  const bds = M.badges(), got = bds.filter(b => b.got).length;
  const badgeCard = `<div class="card"><div class="more"><h3 style="margin:0">Rozetler</h3><span class="count">${got} / ${bds.length}</span></div><div class="bdg">${bds.map(b => `<div class="bd${b.got ? ' got' : ''}"><i>${b.ico}</i><b>${b.name}</b><span>${b.desc}</span></div>`).join('')}</div></div>`;
  return `<div class="hdr"><div class="brand">Yıllık rapor</div><h1>${y}</h1>${yearBar()}</div>${hero}${limit}${empty}${chart}${table}${heat}${wdCard}${typeCard}${tagCard}${holCard}${badgeCard}`;
};

/* ---------- AYARLAR ---------- */
M.netCard = () => {
  const s = M.db.settings, yn = (b, a) => `<div class="seg"><button class="${b ? 'on' : ''}" data-act="${a}" data-v="1">Evet</button><button class="${!b ? 'on' : ''}" data-act="${a}" data-v="0">Hayır</button></div>`;
  let body = '';
  if (s.net.on && !s.salaries.length) body = '<p class="note">Net hesabı için yukarıya <b>brüt aylık maaşını</b> gir (yalnız saatlik ücret yeterli değil: vergi dilimi maaşa bağlıdır).</p>';
  if (M.netOn()) {
    const t = M.today(), y = Number(t.slice(0, 4)), m = Number(t.slice(5, 7)), p = M.payYear(y, Array(12).fill(0))[m - 1];
    body = `<div class="set"><div><div class="l">SGK + işsizlik kesintisi</div><div class="s">İşçi payı %14 + %1 (tavana kadar)</div></div>${yn(s.net.sgk, 'netSgk')}</div>
    <div class="set"><div><div class="l">Asgari ücret istisnası</div><div class="s">Gelir ve damga vergisi istisnası uygulansın</div></div>${yn(s.net.exempt, 'netEx')}</div>
    <div class="kv"><span>Bu ay maaşın (brüt → net)</span><b>${M.fmtMoney(p.gross)} → ${M.fmtMoney(p.net)}</b></div>
    <div class="kv"><span>Kesintiler (SGK / vergi / damga)</span><b>${M.fmtMoney(p.sgk)} / ${M.fmtMoney(p.tax)} / ${M.fmtMoney(p.dv)}</b></div>`;
  }
  return `<div class="card"><h3>🧾 Net (ele geçen) hesabı</h3>
    <div class="set"><div><div class="l">Net tutarı göster</div><div class="s">Brüt yanında ele geçen mesai ücreti</div></div>${yn(s.net.on, 'netOn')}</div>${body}
    <p class="note">Net tutar <b>tahmindir</b>: yıl başından kümülatif gelir vergisi dilimi, SGK/işsizlik, damga vergisi ve asgari ücret istisnası hesaba katılır. Mesai, yapıldığı ayın bordrosunda ödenmiş sayılır; yıl başından çalıştığın varsayılır. Mesai yıllık vergi dilimini erken yükseltirse sonraki ayların maaş neti de biraz düşebilir; bu etki ayrıca gösterilmez. Özel indirim (engelli, BES, nafaka vb.) yoktur. Parametreler: ${M.netPar(2026) ? '2026 gelir vergisi tarifesi, SGK tavanı 297.270 ₺, asgari ücret 33.030 ₺' : ''}. Kesin tutar için bordronuza bakın.</p></div>`;
};
M.calcBox = () => {
  const s = settings(), hr = M.hourlyAt(M.today());
  return M.moneyOn() ? `<div class="calc"><div><span>Saatlik ücret</span><b>${M.fmtMoney2(hr)}</b></div><div><span>Hafta içi ×${s.mult.normal}</span><b>${M.fmtMoney2(hr * s.mult.normal)}</b></div><div><span>Hafta sonu ×${s.mult.weekend}</span><b>${M.fmtMoney2(hr * s.mult.weekend)}</b></div><div><span>Resmi tatil ×${s.mult.holiday}</span><b>${M.fmtMoney2(hr * s.mult.holiday)}</b></div></div>` : '';
};
const setV = () => {
  const s = settings();
  const th = (v, l) => `<button class="${s.theme === v ? 'on' : ''}" data-act="theme" data-v="${v}">${l}</button>`;
  const num = (id, v, ph = '0', step = '1') => `<input class="num" id="${id}" type="number" inputmode="decimal" min="0" step="${step}" value="${v || ''}" placeholder="${ph}">`;
  const txt = (id, v, ph) => `<input class="num txt" id="${id}" type="text" maxlength="40" value="${esc(v || '')}" placeholder="${ph}" autocomplete="off">`;
  const pres = s.presets.slice().sort((a, b) => a - b).map(p => `<span class="chip pr">${dur(p)}<button data-act="delpreset" data-m="${p}" aria-label="Sil">×</button></span>`).join('');
  const cur = s.salaries.length ? s.salaries[s.salaries.length - 1] : null, hr = M.hourlyAt(M.today());
  const raises = s.salaries.length ? s.salaries.map((e, i) => `<div class="kv"><span>${e.from === '2000-01' ? 'Başlangıçtan itibaren' : MONTHS[Number(e.from.slice(5)) - 1] + ' ' + e.from.slice(0, 4) + ' ve sonrası'}</span><b>${M.fmtMoney(e.amount)}${s.salaries.length > 1 ? ` <button class="x" data-act="delraise" data-i="${i}" aria-label="Sil">×</button>` : ''}</b></div>`).join('') : '';
  const calc = M.calcBox();
  const hols = s.customHolidays.map((h, i) => `<div class="kv"><span>${pretty(h.date)}</span><b>${esc(h.name)} <button class="x" data-act="delhol" data-i="${i}" aria-label="Sil">×</button></b></div>`).join('');
  const toFix = M.ot().filter(r => r.type !== 'holiday' && M.isHolidayPay(r.date)).length;
  return `<div class="hdr"><div class="brand">Erdem Mesai Takip</div><h1>Ayarlar</h1></div>
  <div class="card"><h3>💰 Maaş ve mesai ücreti</h3>
    <div class="set"><div><div class="l">Brüt aylık maaş</div><div class="s">Saatlik ücret otomatik hesaplanır</div></div>${num('salary', cur ? cur.amount : 0, '0', '1')}</div>
    <div class="set"><div><div class="l">Aylık çalışma saati</div><div class="s">Varsayılan 225 (30 gün × 7,5 sa)</div></div>${num('divisor', s.divisor, '225', '1')}</div>
    ${cur ? '' : `<div class="set"><div><div class="l">veya saatlik ücret</div><div class="s">Maaş girmeden doğrudan saatlik ücret</div></div>${num('wage', s.wage, '0', '0.01')}</div>`}
    ${calc}${raises}
    <button class="btn out" data-act="raise" style="margin-top:12px">＋ Zam / maaş değişikliği ekle</button>
    <div class="set" style="margin-top:6px"><div class="l">Hafta içi çarpanı</div>${num('mN', s.mult.normal, '1.5', '0.05')}</div>
    <div class="set"><div class="l">Hafta sonu çarpanı</div>${num('mW', s.mult.weekend, '1.5', '0.05')}</div>
    <div class="set"><div class="l">Resmi tatil çarpanı</div>${num('mH', s.mult.holiday, '2', '0.05')}</div>
    <div class="set"><div class="l">Para birimi</div><input class="num" id="cur" type="text" maxlength="4" value="${esc(s.cur)}"></div>
    <p class="note">Saatlik ücret = brüt maaş ÷ aylık çalışma saati. Fazla mesai genelde %50 zamlıdır (×1.5), resmi tatilde çarpanı işyerinde uygulanana göre ayarla. Net (ele geçen) tutar aşağıdaki karttan hesaplanır.</p></div>
  ${M.netCard()}
  <div class="card"><h3>🎌 Resmi tatiller</h3>
    <div class="set"><div><div class="l">Arife günleri tatil sayılsın</div><div class="s">13:00 sonrası yarım gün; mesai tatil çarpanıyla hesaplanır</div></div><div class="seg"><button class="${s.arife ? 'on' : ''}" data-act="arife" data-v="1">Evet</button><button class="${!s.arife ? 'on' : ''}" data-act="arife" data-v="0">Hayır</button></div></div>
    ${hols}<button class="btn out" data-act="addhol" style="margin-top:10px">＋ Özel tatil günü ekle</button>
    ${toFix ? `<button class="btn soft" data-act="applyhol">${toFix} eski kaydı resmi tatil olarak güncelle</button>` : ''}
    <p class="note">Türkiye resmi tatilleri ve bayramlar (${M.HOL_TABLE_LAST} yılına kadar Diyanet takvimi, sonrası tahmini) otomatik tanınır. Şirketin verdiği ek izin/köprü günlerini özel gün olarak ekleyebilirsin.</p></div>
  <div class="card"><h3>Hedefler</h3>
    <div class="set"><div><div class="l">Aylık hedef</div><div class="s">Saat · 0 = hedef yok</div></div>${num('goal', s.goal, '0', '0.5')}</div>
    <div class="set"><div><div class="l">Yıllık sınır</div><div class="s">Saat · varsayılan 270 (İş Kanunu), 0 = kapalı</div></div>${num('ylim', s.yearLimit, '0', '1')}</div></div>
  <div class="card"><h3>Rapor bilgileri</h3>
    <div class="set"><div class="l">Ad soyad</div>${txt('pfName', s.profile.name, 'Erdem …')}</div>
    <div class="set"><div class="l">İşyeri</div>${txt('pfCompany', s.profile.company, 'Şirket adı')}</div>
    <div class="set"><div class="l">Sicil no</div>${txt('pfEmp', s.profile.empNo, '—')}</div>
    <div class="set"><div class="l">Yönetici</div>${txt('pfMgr', s.profile.manager, 'Onaylayan')}</div>
    <p class="note">PDF ve Excel raporlarında başlık ve imza alanında görünür.</p></div>
  <div class="card"><h3>Hızlı şablonlar</h3><div class="chips" style="margin-top:0">${pres}<button class="chip alt" data-act="addpreset">＋ Ekle</button></div><p class="note">Özet ekranında tek dokunuşla bugüne mesai eklemek için kullanılır.</p></div>
  <div class="card"><h3>Görünüm ve takvim</h3>
    <div class="set"><div class="l">Tema</div><div class="seg">${th('auto', 'Otomatik')}${th('light', 'Açık')}${th('dark', 'Koyu')}</div></div>
    <div class="set"><div class="l">Hafta başlangıcı</div><div class="seg"><button class="${s.weekStart === 1 ? 'on' : ''}" data-act="wstart" data-v="1">Pzt</button><button class="${s.weekStart === 0 ? 'on' : ''}" data-act="wstart" data-v="0">Paz</button></div></div>
    <div class="set"><div><div class="l">İzin bakiyesi</div><div class="s">Mesaiyi izne çevirmeyi takip et</div></div><div class="seg"><button class="${!s.bank ? 'on' : ''}" data-act="bank" data-v="0">Kapalı</button><button class="${s.bank ? 'on' : ''}" data-act="bank" data-v="1">Açık</button></div></div></div>
  <div class="card"><h3>Güvenlik</h3>
    <div class="set"><div><div class="l">PIN kilidi</div><div class="s">${s.pin ? 'Açık · 30 sn sonra otomatik kilitlenir' : 'Kapalı · 4 haneli PIN ile koru'}</div></div><div class="seg"><button class="on" data-act="pin">${s.pin ? 'Kapat' : 'Aç'}</button></div></div></div>
  <div class="card"><h3>Raporlar ve veri</h3><div class="btns">
    <button class="btn soft" data-act="printMonth">Aylık PDF</button><button class="btn soft" data-act="printYear">Yıllık PDF</button>
    <button class="btn soft" data-act="xlsxMonth">Aylık Excel</button><button class="btn soft" data-act="xlsxYear">Yıllık Excel</button>
    <button class="btn out" data-act="csvMonth">Bu ay · CSV</button><button class="btn out" data-act="csvYear">Yıl · CSV</button>
    <button class="btn out" data-act="csvAll">Tümü · CSV</button><button class="btn out" data-act="share">Ay özetini paylaş</button>
    <button class="btn out" data-act="backup">Yedek indir</button><button class="btn out" data-act="restore">Yedeği yükle</button></div>
    <p class="note">Excel dosyası biçimli ve toplam formüllüdür. PDF dosyası olarak hazırlanır; açılan paylaşım menüsünden <b>Dosyalara Kaydet</b> veya Mail / WhatsApp seç. Kayıtlar yalnızca bu cihazdaki tarayıcıda saklanır — düzenli yedek al.${s.lastBackup ? ' Son yedek: ' + pretty(s.lastBackup.slice(0, 10)) + '.' : ''}</p></div>
  <div class="card"><h3>Tehlikeli alan</h3><button class="btn dng" data-act="wipe">Tüm kayıtları sil</button></div>
  <div class="note" style="text-align:center;padding:4px 0 10px">Erdem Mesai Takip v5 · ${M.db.records.length} kayıt</div>`;
};

/* ---------- çizim ---------- */
let lastView = null;
M.listRows = listRows;
M.rowHtml = rowHtml;
M.render = () => {
  document.documentElement.dataset.theme = settings().theme;
  const scr = document.getElementById('screen'), top = lastView === st.view ? scr.scrollTop : 0;
  const v = { home: homeV, cal: calV, year: yearV, set: setV }[st.view] || homeV;
  scr.innerHTML = v();
  scr.scrollTop = top; lastView = st.view;
  document.querySelectorAll('.tab[data-v]').forEach(t => t.classList.toggle('on', t.dataset.v === st.view));
};
})();
